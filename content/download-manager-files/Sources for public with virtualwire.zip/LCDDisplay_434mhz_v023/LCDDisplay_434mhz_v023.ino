
/*
Wireless LCD Display module. Receive data via 434Mhz and display text on an LCD display.
Should run on Arduino Nano

Changelog:
v0.1 - 13 october 2012 - Initial version.
v0.2 - 15 october 2012 - working on 16x2 display
v0.3 - 21 october 2012 - added long domo variable that contains status of switches received from domotica box
This should be an & or | statement to get correct values.
v0.5 - 26 october 2012 - Added watchdog for received messages. If no data is received, after 90 seconds a X will appear on line 2 position 15
v0.6 - 26 october 2012 - added DHT11 temperature sensor
v0.7 - 28 october 2012 - added DS1307 RTC
v0.8 - 12 november 2012 - added sun & moon rise/set time reception 
v0.9a dht22 - 17 november 2012 - Used another DHT library to be compatible with DHT11, DHT21, DHT22. Changed code to use DHT22
v0.20 - 19 november - Changed from using String object to char Arrays. Strings seem to have issues.
v0.21 - 22 november - LCD Display for 20x4 build
v0.22 - 2 december - Added LDR to detect environment Light (Use as switch or dim display ?!?!)
v0.23 - 2 december - implemented another data reception structure. Now there is one indicator received and variables are fixed positions in the array

To Do: 
- implementeren van een scroll mechanisme voor messages
- cycle modus om te wisselen tussen message en statistieken
- drukknopje om door opties te springen
- Niet in alle gevallen LCD scherm wissen, maar blijven overschrijven (bijv. tijd of temperatuur)
- Tijd iedere dag een paar keer vanaf de domotica gateway naar de RTC laten versturen.

Variable receive strings. This is the structure in which variables are received:
(TX434= is removed by the domotica gateway and therefore niet received by the LCD Display unit)
Virtual Wire is limited to 27 bytes transfer!

V1,actual,today,peak,total,
V2,TotalActual,Nactual,NactualReturn,GasUsage,

*/

#include <VirtualWire.h>
#include <MsTimer2.h>
#include <LiquidCrystal.h>
#include <DHT.h>
#include <Time.h>
#include <Wire.h>
#include <DS1307RTC.h>



#define DHTPIN 3  //pin voor DHT temp sensor
#define LDRPIN 2  //pin voor LDR Light sensor

// Uncomment whatever type you're using!
//#define DHTTYPE DHT11   // DHT 11 
#define DHTTYPE DHT22   // DHT 22  (AM2302)
//#define DHTTYPE DHT21   // DHT 21 (AM2301)

DHT dht(DHTPIN, DHTTYPE);

// initialize the library with the numbers of the interface pins

LiquidCrystal lcd(11,10,9,8,7,6);
//String actual,peak,today,total;
char actual[6];
char peak[6];
char today[6];
char total[6];

//values from 'slimme meter';
char NactualReturn[6]; //actuele teruglevering
char Nactual[6]; //actueel vermogen uit net
char Nreturn[6]; //teruglever vermogen naar net
char Npeak[6]; //piek vermogen gedurende xx minuten
char NetToday[6]; //totaal vermogen verbruikt vandaag
char TotalToday[6]; // totaal meterstand
char GasUsage[6]; // Gas verbruik op huidige dag
char TotalActual[6]; //Actueel energie verbruik woning


String message;
long domo=0;


char LampA_Status = ' ';
char LampB_Status = ' ';
char LampC_Status = ' ';
char LampD_Status = ' ';
char LampE_Status = ' ';
char LampF_Status = ' ';
char TuinVoor_Status = ' ';
char TuinMidden_Status = ' ';
char DeurLinks_Status = ' ';
char DeurRechts_Status = ' ';
char DeurAchter_Status = ' ';
char TuinAchter_Status = ' ';

int button = 3;
int screen = 0;
long vorigeMillis = 0;
int cnt=0;
float humidity,temp;


volatile int TempTimer=0;
volatile int WatchDogTimer=0;

//2D char Array. initialise with 10 characters + zero (I don't know how to do it differently and this works ;-)
char* Text[]={"aaaaaaaaaa","bbbbbbbbbb","cccccccccc","dddddddddd","eeeeeeeeee","ffffffffff","gggggggggg","hhhhhhhhh","iiiiiiiiii","jjjjjjjjjj","kkkkkkkkkk"};


char sunset[6];
char sunrise[6];
char moonset[6];
char moonrise[6];



void setup(){
   pinMode(button, INPUT_PULLUP);   
  
  Serial.begin(9600);
    Serial.println("started");
    // set up the LCD's number of columns and rows:
    lcd.begin(20, 4);
    lcd.clear();
    lcd.print("Start W-LCD 0.23");
    lcd.setCursor(0,1);
    lcd.print("www.vdsar.net");
    

    
    
    
    //Initialize virtual wire connection
    
    vw_set_rx_pin(12);
    vw_setup(2000);
    vw_rx_start(); 
  
  //get time from DS1307 RTC  
  setSyncProvider(RTC.get);   // the function to get the time from the RTC
  if(timeStatus()!= timeSet) {
     Serial.println("Unable to sync with the RTC");
     lcd.setCursor(0,3);
     lcd.print("No RTC Sync");
  }
     
  else{
     Serial.println("RTC has set the system time");
     lcd.setCursor(0,3);
     lcd.print("Time Set by RTC");  
  }
  
}


void loop(){
  
  
  
  
 if(millis() > vorigeMillis +10000) {
  vorigeMillis = millis();
// if(!digitalRead(button)){ //deze uncommenten voor drukknop
  
   if(screen < 3) // 0, 1, 2 display layouts.
     screen++;
   else
     screen = 0;
    
       DisplayData(screen);

}
  
  if(TempTimer > 0){  //if TempTimer = 1, then 2 seconds have passed and DHT22 can be read again.
    getTemp();
    TempTimer = 0;
  }
     
  //Ontvang data via 434Mhz receiver
   
   uint8_t buf[VW_MAX_MESSAGE_LEN];
   uint8_t buflen = VW_MAX_MESSAGE_LEN;
   
   if (vw_get_message(buf, &buflen)){ // Non-blocking
   
    // Message with a good checksum received, dump HEX
     vw_rx_stop();

     //some kind of watchdog timer. normally a message is received every 60 seconds. To know if data on the LCD display is current or not, the MsTimer2 displays an indicator on the LCD
     //when more then 45 seconds have passed. 
     MsTimer2::stop();
     MsTimer2::set(2000 , MessageWatchDog); // 2.000ms period (na 22 x 2 seconden wordt MessageGuard gestart. in principe gebeurt dit nooit, aangezien er elke minuut een bericht binnen moet komen
     MsTimer2::start(); 
  
    int j=0;
    int p=0; 
    for(int i=0;i<buflen && j<10;i++){
      Serial.print(char(buf[i]));
      if(char(buf[i]) != ','){
        Text[j][p] = char(buf[i]);
        p++;
      }
      else if(char(buf[i]) == ','){
        Text[j][p] = '\0';
        j++;
        p=0;
      }

    } 
    
   
    Serial.println("<END>");   //for debugging to see if there are strange characters behind the received data.   
    for(int a=0;a<10;a=a+2){
      Serial.print(Text[a]); //debugging
      Serial.print("   "); //debugging
      Serial.println(Text[a+1]); //debugging to print the contents of the array ;-)
    }
     
      GetDataFromArray(); //haal de data uit de array en verwerk het.
      DisplayData(screen);
      
     for(int y=0;y<10;y++){ //clean string array
        Text[y][0]='\0';
      }

      vw_rx_start(); 

 }
}
 
void GetDataFromArray(){
    
    if(strcmp(Text[0],"V1") ==0){
        strcpy (actual,Text[1]);
        strcpy (today,Text[2]);
        strcpy (peak,Text[3]);
        strcpy (total,Text[4]);
      //  Serial.println("V1 is");
      //  Serial.println(actual);
      //  Serial.println(today);
      //  Serial.println(peak);
      //  Serial.println(total);
        
    }
    else   if(strcmp(Text[0],"V2") ==0){
        strcpy (TotalActual,Text[1]);
        strcpy (Nactual,Text[2]);
        strcpy (NactualReturn,Text[3]);
        strcpy (GasUsage,Text[4]);
      //  Serial.println("V2 is");
      //  Serial.println(TotalActual);
      //  Serial.println(Nactual);
      //  Serial.println(NactualReturn);
      //  Serial.println(GasUsage);
    } 
      
      
      else if (strcmp(Text[0],"TXT") ==0){
            Serial.println("TXT received");
            message = Text[1];
      }
      
       else if (strcmp(Text[0],"Domo") ==0){ //the value past DOMO contains the status of the switches in HEX binary (255 = 11111111, so all are on)
        Serial.println("Nu Wordt DOMO aangeroepen");
        domo = atol(Text[1]);
        Serial.print("Domo Received: ");
        Serial.println(domo);
        ProcessReceivedDomo(domo);
      }
 
 
  else if (strcmp(Text[0],"SUN") ==0){
            strcpy (sunrise,Text[1]);
            strcpy (sunset,Text[2]);
            strcpy (moonrise,Text[3]);
            strcpy (moonset,Text[4]);
            //Serial.println("SUN en MOON");
            //Serial.println(sunrise);
            //Serial.println(sunset);
            //Serial.println(moonrise);
            //Serial.println(moonset);


  }
 } 


 
void MessageWatchDog(){ // is called by MsTimer2 to show an X on the display when no data has been received for 'period' seconds.
  
  TempTimer = 1;
  if(WatchDogTimer > 22){ //timer is set on 2 seconds. So this funtion is called 22 x 2 seconds is 44 seconds before mark is set.
    lcd.setCursor(15,1);
    lcd.print("X");
    WatchDogTimer = 0;
  }
  DisplayData(screen);
 }
 
   
void DisplayData(int Screen){
 

  
if(Screen == 1 && message == ""){ // Domotica lights status

  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Light: ");
  lcd.print(LampA_Status);
  lcd.print(LampB_Status);
  lcd.print(LampC_Status);
  lcd.print(LampD_Status);
  lcd.print(LampE_Status);
  lcd.setCursor(0,1);
  lcd.print("Tuin: ");
  lcd.print(TuinVoor_Status);
  lcd.print(TuinMidden_Status);
  lcd.print(TuinAchter_Status);
  lcd.print(DeurAchter_Status);
  lcd.print(DeurLinks_Status);
  lcd.print(DeurRechts_Status);
 
}

if(Screen == 0 && message ==""){
  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("A: ");
  lcd.setCursor(8-strlen(actual),0);
  lcd.print(actual);
  lcd.print("W"); 
  lcd.setCursor(11,0);
  lcd.print("C: ");
  lcd.setCursor(18-strlen(TotalActual),0);
  lcd.print(TotalActual);
  lcd.print("W");
  
  lcd.setCursor(0,1);
  lcd.print("P: ");
  lcd.setCursor(8-strlen(peak),1);
  lcd.print(peak);
  lcd.print("W");
  lcd.setCursor(11,1);
  lcd.print("I: ");
  lcd.setCursor(18-strlen(Nactual),1);
  lcd.print(Nactual);
  lcd.print("W");
  
  lcd.setCursor(0,2);
  lcd.print("T: ");
  lcd.setCursor(8-strlen(today),2);
  lcd.print(today);
  lcd.print("Wh");
  lcd.setCursor(11,2);
  lcd.print("E: ");
  lcd.setCursor(18-strlen(NactualReturn),2);
  lcd.print(NactualReturn);
  lcd.print("W");
  
  
  lcd.setCursor(0,3);
  lcd.print("Y: ");
  lcd.setCursor(8-strlen(total),3);
  lcd.print(total);
  lcd.print("kWh");
  lcd.setCursor(18-strlen(GasUsage),3);
  lcd.print(GasUsage);
  lcd.print("M3");
  
  
}

if(Screen == 2 && message ==""){
  lcd.clear();
  if(atoi(actual) == 0){
    lcd.setCursor(0,0);
    lcd.print("Geen zon");
    
  }
  else if(atoi(actual) >= 2500){
  lcd.setCursor(0,0);
  lcd.print("*** ");
  lcd.setCursor(7-strlen(actual),0);
  lcd.print(actual);
  lcd.print("W");
  }
  else if(atoi(actual) >= 1500){
  lcd.setCursor(0,0);
  lcd.print("** ");
  lcd.setCursor(7-strlen(actual),0);
  lcd.print(actual);
  lcd.print("W");
  }
  else if(atoi(actual) >= 100){
  lcd.setCursor(0,0);
  lcd.print("*");
  lcd.setCursor(7-strlen(actual),0);
  lcd.print(actual);
  lcd.print("W");
  }
  else if(atoi(actual) > 0){
  lcd.setCursor(0,0);
 // lcd.print("");
  lcd.setCursor(7-strlen(actual),0);
  lcd.print(actual);
  lcd.print("W");
  }
  
  lcd.setCursor(19-strlen(TotalActual),0);
  lcd.print(TotalActual);
  lcd.print("W");
  
  lcd.setCursor(14,2);
  //lcd.print("T:");
  lcd.print(temp,1); // the ,1 is to limit 0,1 instead of 0,10
  lcd.print((char)223);
  lcd.print("C");
  lcd.setCursor(14,3);
 // lcd.print("H:");
  lcd.print(humidity,1);
  lcd.print("%");
  //lcd.setCursor(0,3);
  //lcd.print("Dew Point: ");
 // lcd.print(dewPoint(temp, humidity));
  
 lcd.setCursor(0,2);
  lcd.print(hour());
  printDigits(minute());
 // printDigits(second());
  lcd.setCursor(0,3);
  //lcd.print(dayStr(weekday()));
  lcd.print(dayShortStr(weekday()));
  lcd.print(" ");
  lcd.print(day());
  lcd.print(" ");
  lcd.print(monthShortStr(month()));
//  lcd.print(" ");
//  lcd.print(year());

}
  


if(Screen == 3 && message == ""){ //display sun & moon set/rise times
  lcd.clear();
  lcd.print("Sun:  ");
  lcd.setCursor(11-strlen(sunrise),0);
  lcd.print(sunrise);
  lcd.print(" - ");
  lcd.setCursor(19-strlen(sunset),0);
  lcd.print(sunset);
  lcd.setCursor(0,1);
  lcd.print("Moon: ");
  lcd.setCursor(11-strlen(moonrise),1);
  lcd.print(moonrise);
  lcd.print(" - ");
  lcd.setCursor(19-strlen(moonset),1);
  lcd.print(moonset);
  
  
  
}
  
if (message !=""){
  //implement some scrolling mechanism.
  lcd.clear();
  lcd.print(message);
  message= "";
}
  
  
}

  
void ProcessReceivedDomo(long Domo){
  
 
 LampA_Status = ' ';
 LampB_Status = ' ';
 LampC_Status = ' ';
 LampD_Status = ' ';
 LampE_Status = ' ';
 LampF_Status = ' ';
 TuinVoor_Status = ' ';
 TuinMidden_Status = ' ';
 DeurLinks_Status = ' ';
 DeurRechts_Status = ' ';
 DeurAchter_Status = ' ';
 TuinAchter_Status = ' ';

  if((Domo & 0x8000) == 0x8000)
    LampA_Status = 'A';  // 1000.0000.0000.0000
  if((Domo & 0x4000) == 0x4000)
    LampB_Status = 'B'; // 0100.0000.0000.0000
  if((Domo & 0x2000) == 0x2000)
    LampC_Status = 'C'; // 0010.0000.0000.0000
  if((Domo & 0x1000) == 0x1000)
    LampD_Status = 'D'; // 0001.0000.0000.0000
  if((Domo & 0x0800) == 0x0800)
    LampE_Status = 'E'; // 0000.1000.0000.0000
  if((Domo & 0x0400) == 0x0400)
    LampF_Status = 'F'; // 0000.0100.0000.0000
  if((Domo & 0x0200) == 0x0200) 
    TuinVoor_Status = 'V'; // 0000.0010.0000.0000   Tuinvoor
  if((Domo & 0x0100) == 0x0100)
    TuinMidden_Status = 'M'; // 0000.0001.0000.0000   TuinMidden
  if((Domo & 0x0080) == 0x0080)
    DeurLinks_Status = 'L'; // 0000.0000.1000.0000   Deurlinks
  if((Domo & 0x0040) == 0x0040)
    DeurRechts_Status = 'R'; // 0000.0000.0100.0000   Deurrechts
  if((Domo & 0x0020) == 0x0020)
    DeurAchter_Status = 'A'; // 0000.0000.0010.0000    
  if((Domo & 0x0010) == 0x0010)
    TuinAchter_Status = 'S'; // 0000.0000.0001.0000    
  
  
}
  
double dewPoint(double celsius, double humidity)
{
	double A0= 373.15/(273.15 + celsius);
	double SUM = -7.90298 * (A0-1);
	SUM += 5.02808 * log10(A0);
	SUM += -1.3816e-7 * (pow(10, (11.344*(1-1/A0)))-1) ;
	SUM += 8.1328e-3 * (pow(10,(-3.49149*(A0-1)))-1) ;
	SUM += log10(1013.246);
	double VP = pow(10, SUM-3) * humidity;
	double T = log(VP/0.61078);   // temp var
	return (241.88 * T) / (17.558-T);
}

void printDigits(int digits){
  // utility function for digital clock display: prints preceding colon and leading 0
  lcd.print(":");
  if(digits < 10)
    lcd.print('0');
  lcd.print(digits);
}

void getTemp(){
   
  humidity = dht.readHumidity();
  temp = dht.readTemperature();
  
  
  if (isnan(temp) || isnan(humidity)) { //isnan (is not a number)
    lcd.setCursor(0,1);
    lcd.print("Failed to read DHT22");
  } 
      
}

