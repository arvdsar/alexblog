/*
This file contains the ReceiveRemoteControl ISR function. The Arduino receives commands from the Action/blokker/elro/klikaan-uit controls on a 
certain setting (define yourself). After receiving transmits the command using another settings to the wallplug receivers.
The goal of this approach is:
- one remote of one brand can be used to control another brand wallplug receiver
- reach of the TX from Arduino is much bigger than the remotecontroller itself. So better response on the remote (with a little delay of the Arduino though)
- Because all switching is handled by Arduino, the state of the switch is known. This can be used for a dashboard or anything.
*/


void ReceiveRemoteControl(unsigned long receivedCode, unsigned int period){ //Interrupt Service Routine for handling received code of remote control


  RemoteReceiver::disable();
  
  //uncomment the following to see the code in the serial terminal of your remote control
  Serial.print("Code: ");
  Serial.println(receivedCode);
 // Serial.print(", period duration: ");
  //Serial.print(period);
  //Serial.println("us.");
  


  switch(receivedCode){
    //check the codes that your remote is sending while pushing a button. Enter those codes here and enter the string which is used in StartSwitching function
    // Configure your remote control device, and start pushing the remote control buttons (A on, B On etc.) The code above will show you the value
    //that has been received (receivedCode). That code should be ued in the cases below. If you push A ON at the remote controller
    // and value 123345 is received, put it in case 123345. And so on. the current values below are just random junk (I don't want you to see which codes I use ;-)
    
    case 123345:  
      StartSwitching("lampA_ON");
      break;   
    
    case 234234:
     StartSwitching("lampA_OFF");
     break;
      
    case 23234:
     StartSwitching("lampB_ON");
     break;
     
    case 234234:
     StartSwitching("lampB_OFF");
     break;
     
    case 2343:
     StartSwitching("lampC_ON");
     break;
     
    case 3453323477:
     StartSwitching("lampC_OFF");
     break;
     
    case 34524489:
     StartSwitching("lampD_ON");
     break;   
     
    case 345485:
     StartSwitching("lampD_OFF");
     break;
     
    case 23423:
     StartSwitching("lampE_ON");
     break;
     
    case 345521:
     StartSwitching("lampE_OFF");
     break;
     
    case 2342:
    StartSwitching("Bedtijd");
    break;
    
    case 3434061:
    StartSwitching("Vertrekken");
    break;
    
    case 3444267:
    StartSwitching("Opstaan");
    break;
    
     case 34234: //Elro Remote D_ON just for testing
     StartSwitching("Opstaan");
     break;     
     
     case 42343: //Elro Remote D_OFF just for testing
     StartSwitching("Vertrekken");
     break;   
     
    }
 
    RemoteReceiver::enable();
  }
