/*
This file contains the function to periodically update the Remote connected LCD display via 434Mhz.
Some intelligence is build to transfer only necessary data

*/

void sendSwitchStatus(){
  
  //interrupts(); //enable interrupts which were disabled by RemoteSwitch functions
 // Serial.print("Start ToLCD : ");
  
  DomoStatus = 0x0000; // 00000000.00000000 (16 bits)
  
  if(LampA_Status == 1)
    DomoStatus = DomoStatus | 0x8000; // 1000.0000.0000.0000 
  if(LampB_Status == 1)
    DomoStatus = DomoStatus | 0x4000; // 0100.0000.0000.0000
  if(LampC_Status == 1)
    DomoStatus = DomoStatus | 0x2000; // 0010.0000.0000.0000
  if(LampD_Status == 1)
    DomoStatus = DomoStatus | 0x1000; // 0001.0000.0000.0000
  if(LampE_Status == 1)
    DomoStatus = DomoStatus | 0x0800; // 0000.1000.0000.0000
  if(LampF_Status == 1)
    DomoStatus = DomoStatus | 0x0400; // 0000.0100.0000.0000
  if(digitalRead(RELAY1) == 0) 
    DomoStatus = DomoStatus | 0x0200; // 0000.0010.0000.0000   Tuinvoor
  if(digitalRead(RELAY2) == 0)
    DomoStatus = DomoStatus | 0x0100; // 0000.0001.0000.0000   TuinMidden
  if(digitalRead(RELAY4) == 0)
    DomoStatus = DomoStatus | 0x0080; // 0000.0000.1000.0000   Deurlinks
  if(digitalRead(RELAY3) == 0)
    DomoStatus = DomoStatus | 0x0040; // 0000.0000.0100.0000   Deurrechts
  if(DeurAchter_Status == 1)
    DomoStatus = DomoStatus | 0x0020; // 0000.0000.0010.0000    
  if(TuinAchter_Status == 1)
    DomoStatus = DomoStatus | 0x0010; // 0000.0000.0001.0000    
   
  //etc etc. bij aanroep alles op 0, dan met OR alle bits zetten die aan moeten. 
  
 //transmit the DomoStatus value from above using the 434Mhz functions. 
          RemoteReceiver::disable(); //disable the 434mhz receiver of the remote switch library to prevent receiving date send by the arduino itself
          interrupts();   // enable interrupts while we are still in the ISR of RemoteReceiver. Interrupt neccessary for vw_wait_tx() below.  
          TX_Message2 = "Domo,";
          TX_Message2 +=DomoStatus; // Domo is the value recognized by the LCD receiver. Value behind the comma is processed.
          TX_Message2 +=","; //from version 0.20 of LCDDisplay_434Mhz it is necessary to close string with a comma
          TX434Send(TX_Message2); //use function tot send data.
      
          TX_Message2 = ""; //clear 
      
        
        RemoteReceiver::enable();
 
 
}
