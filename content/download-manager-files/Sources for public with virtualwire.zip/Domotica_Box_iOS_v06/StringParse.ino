void StringParse(String inputString){
 
  
    String TMP_Message = inputString.substring(6); // start reading at position 6 (TX434=here is some text to display
    char msg[TMP_Message.length()+1];
    TMP_Message.trim();
    TMP_Message.toCharArray(msg,TMP_Message.length()+1);

    int j=0;
    for(int i=0;i<TMP_Message.length() && j<10;i++){
      
      if(msg[i] != ',')
        Text[j] += msg[i];
      else if(msg[i] == ','){
        Text[j] += '\0';
        j++;
      }
    }        
      GetDataFromArray(); //Get data from the array and process data
      
      for(int y=0;y<10;y++){ // erase array after processing before with GetDataFromArray()
        Text[y]="";
      }
    
 
     
 }
 
 
void GetDataFromArray(){ //add more IF statements (and enlarge Text Array when more variables are to be processed)
                         //this function only process the data from array and store in local variables. 
  
  
  
    if(Text[0] == "V1"){
      char value[Text[1].length()+1];
      Text[1].toCharArray(value,Text[1].length()+1);
      actual=atoi(value);
      
      char value1[Text[2].length()+1];
      Text[2].toCharArray(value1,Text[2].length()+1);
      today=atoi(value1);
      
      char value2[Text[3].length()+1];
      Text[3].toCharArray(value2,Text[3].length()+1);
      peak=atoi(value2);
      
      char value3[Text[4].length()+1];
      Text[4].toCharArray(value3,Text[4].length()+1);
      total=atoi(value3);

      
    }
    
    else if(Text[0] == "V2"){
      
      char value[Text[1].length()+1];
      Text[1].toCharArray(value,Text[1].length()+1);
      TotalActual = atoi(value);
      
      char value1[Text[2].length()+1];
      Text[2].toCharArray(value1,Text[2].length()+1);
      Nactual = atoi(value1);
    
      char value2[Text[3].length()+1];
      Text[3].toCharArray(value2,Text[3].length()+1);
      NactualReturn = atoi(value2);
    
      char value3[Text[4].length()+1];
      Text[4].toCharArray(value3,Text[4].length()+1);
      GasUsage = atof(value3);    
      
    }
}
  
//extra IF statements toevoegen als er meer waarden door domoticabox zelf gebruikt moeten worden (zoals iOS messages)

 
