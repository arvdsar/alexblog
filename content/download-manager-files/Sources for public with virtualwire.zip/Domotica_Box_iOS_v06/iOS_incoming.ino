/**
*
*
* This function is called when a new message is received from the iOS device and belongs to the IOSController of Arduino Manager.
* It's in a separate file only because it's getting a long long list of statements.
*
*/

void processIncomingMessages(char *variable, char *value) {

  //Lamp A
  if (strcmp(variable,"LampA")==0) {
    switch(atoi(value)){
      case 0:
        StartSwitching("lampA_OFF");
        break;
      case 1:
        StartSwitching("lampA_ON");
        break;
      default:
      break;
      }
  }
  //Lamp B 
   if (strcmp(variable,"LampB")==0) {
    switch(atoi(value)){
      case 0:
        StartSwitching("lampB_OFF");
        break;
      case 1:
        StartSwitching("lampB_ON");
        break;
      default:
      break;
      }
  }
  
  //Lamp C
  if (strcmp(variable,"LampC")==0) {
    switch(atoi(value)){
      case 0:
        StartSwitching("lampC_OFF");
        break;
      case 1:
        StartSwitching("lampC_ON");
        break;
      default:
      break;
      }
  }
  
  //Lamp D
  if (strcmp(variable,"LampD")==0) {
    switch(atoi(value)){
      case 0:
        StartSwitching("lampD_OFF");
        break;
      case 1:
        StartSwitching("lampD_ON");
        break;
      default:
      break;
      }
  }
  
  //Lamp E
  if (strcmp(variable,"LampE")==0) {
    switch(atoi(value)){
      case 0:
        StartSwitching("lampE_OFF");
        break;
      case 1:
        StartSwitching("lampE_ON");
        break;
      default:
      break;
      }
  }
  
  //Lamp Voortuin 
  if (strcmp(variable,"TuinVoor")==0) {
    switch(atoi(value)){
      case 0:
        StartSwitching("tuinvoor_OFF");
        break;
      case 1:
        StartSwitching("tuinvoor_ON");
        break;
      default:
      break;
      }
  }
  
    //Lamp voortuin midden 
  if (strcmp(variable,"TuinMidden")==0) {
    switch(atoi(value)){
      case 0:
        StartSwitching("tuinmidden_OFF");
        break;
      case 1:
        StartSwitching("tuinmidden_ON");
        break;
      default:
      break;
      }
  }
  
    //Lamp voordeur links 
  if (strcmp(variable,"DeurLinks")==0) {
    switch(atoi(value)){
      case 0:
        StartSwitching("deurlinks_OFF");
        break;
      case 1:
        StartSwitching("deurlinks_ON");
        break;
      default:
      break;
      }
  }
  
    //Lamp voordeur rechts 
  if (strcmp(variable,"DeurRechts")==0) {
    switch(atoi(value)){
      case 0:
        StartSwitching("deurrechts_OFF");
        break;
      case 1:
        StartSwitching("deurrechts_ON");
        break;
      default:
      break;
      }
  }
  
    //Lamp schutting achter 
  if (strcmp(variable,"TuinAchter")==0) {
    switch(atoi(value)){
      case 0:
        StartSwitching("tuinachter_OFF");
        break;
      case 1:
        StartSwitching("tuinachter_ON");
        break;
      default:
      break;
      }
  }
  
  
    //Lamp achterdeur 
  if (strcmp(variable,"DeurAchter")==0) {
    switch(atoi(value)){
      case 0:
        StartSwitching("deurachter_OFF");
        break;
      case 1:
        StartSwitching("deurachter_ON");
        break;
      default:
      break;
      }
  }
  
  //Bedtijd, Alles uit 
  if (strcmp(variable,"Vertrekken")==0) {
    switch(atoi(value)){
      case 0:
        break;
      case 1:
        StartSwitching("Vertrekken");
        break;
      default:
      break;
      }
  }
  
  // AllesAan
  if (strcmp(variable,"Opstaan")==0) {
    switch(atoi(value)){
      case 0:
        break;
      case 1:
        StartSwitching("Opstaan");
        break;
      default:
      break;
      }
  }
  
    // AllesAan
  if (strcmp(variable,"Bedtijd")==0) {
    switch(atoi(value)){
      case 0:
        break;
      case 1:
        StartSwitching("Bedtijd");
        break;
      default:
      break;
      }
  }
/*
  if (strcmp(variable,"Knob1")==0) {

      servoPos = atoi(value);  
      servoPos = map(servoPos, 0, 1023, 0, 180);      
  }

  if (strcmp(variable,"Push1") == 0) {
    
    iosController.temporaryDigitalWrite(CONNECTIONPIN,LOW,500);
  }

#ifdef  SD_SUPPORT   
  if (strcmp(variable,"SD")==0) {
    
    iosController.sendFileList();
  }

  if (strcmp(variable,"SDDL")==0) {
    
    iosController.sendFile(value);
  }
  
#endif
*/
}
