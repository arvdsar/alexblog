// This file contains the statements to switch relays, read data or send wireless transmissions based on 'readString'

void StartSwitching(String readString){
  
  
 
  
        RemoteReceiver::disable(); //disable the 434mhz receiver of the remote switch library to prevent receiving date send by the arduino itself
      
       if (readString.startsWith("TX434")){
          Serial.println("TX434 send request detected");
          TX_Message = readString.substring(6); // start reading at position 6 (TX434=hier staat de text voor display
          
          TX434Send(TX_Message); //call function to send data
          
          StringParse(readString); //parse received readstring to extract the data values for further processing as (ios message)
          no_SendSwitchStatus = 1; //if this is set to one, at the end of the function no switch update is performed
          
          }
      
        
     else if(readString.startsWith("tuin")){  // optimize IF statements. Starts with "tuin"  then ... otherwise Lamp, etc. 
          if(readString == "tuinvoor_ON"){
            digitalWrite(RELAY1, false);
            iosController.writeMessage("TuinVoor",!digitalRead(RELAY1));
            }
          else if (readString == "tuinvoor_OFF"){
            digitalWrite(RELAY1, true);
            iosController.writeMessage("TuinVoor",!digitalRead(RELAY1));
          }
          else if (readString == "tuinmidden_ON"){
            digitalWrite(RELAY2, false);
            iosController.writeMessage("TuinMidden",!digitalRead(RELAY2));
            }
          else if (readString == "tuinmidden_OFF"){
            digitalWrite(RELAY2, true);
            iosController.writeMessage("TuinMidden",!digitalRead(RELAY2));
            }
          else if (readString == "tuinachter_ON"){
            elroTransmitter.sendSignal(1,'E',true);
            TuinAchter_Status=1;
            iosController.writeMessage("TuinAchter",TuinAchter_Status);
            }
           else if (readString == "tuinachter_OFF"){
             elroTransmitter.sendSignal(1,'E',false);
             TuinAchter_Status=0;
             iosController.writeMessage("TuinAchter",TuinAchter_Status);
            }        
        } //end if TUIN
        
        
        else if(readString.startsWith("deur")){  //optimize flow 'deur' 
        
           if (readString == "deurlinks_ON"){
            digitalWrite(RELAY4, false);
            iosController.writeMessage("DeurLinks",!digitalRead(RELAY4));
            }
          else if (readString == "deurlinks_OFF"){
            digitalWrite(RELAY4, true);
            iosController.writeMessage("DeurLinks",!digitalRead(RELAY4));
            }
          else if (readString == "deurrechts_ON"){
            digitalWrite(RELAY3, false);
            iosController.writeMessage("DeurRechts",!digitalRead(RELAY3));
            }
          else if (readString == "deurrechts_OFF"){
            digitalWrite(RELAY3, true);
            iosController.writeMessage("DeurRechts",!digitalRead(RELAY3));
            }
          else if (readString == "deurachter_ON"){
            elroTransmitter.sendSignal(1,'D',true);
            DeurAchter_Status=1;
            iosController.writeMessage("DeurAchter",DeurAchter_Status);
          }    
        
        else if (readString == "deurachter_OFF"){
          elroTransmitter.sendSignal(1,'D',false);
          DeurAchter_Status=0;
          iosController.writeMessage("DeurAchter",DeurAchter_Status);
          }  
        } //end if optimize for 'deur
        
        
        
        
       else if(readString.startsWith("lamp")){ //optimize IF 
        
          if (readString == "lampA_ON"){
            actionTransmitter.sendSignal(1,'A',true);
            LampA_Status=1;
            iosController.writeMessage("LampA",LampA_Status);
          }
        
          else if (readString == "lampA_OFF"){
            actionTransmitter.sendSignal(1,'A',false);
            LampA_Status=0;
            iosController.writeMessage("LampA",LampA_Status);
          }
        
          else if (readString == "lampB_ON"){
            actionTransmitter.sendSignal(1,'B',true);
            LampB_Status=1;
            iosController.writeMessage("LampB",LampB_Status);
          }
        
          else if (readString == "lampB_OFF"){
            actionTransmitter.sendSignal(1,'B',false);
            LampB_Status=0;
            iosController.writeMessage("LampB",LampB_Status);
          }
        
          else if (readString == "lampC_ON"){
            actionTransmitter.sendSignal(1,'C',true);
            LampC_Status=1;
            iosController.writeMessage("LampC",LampC_Status);
          }
        
          else if (readString == "lampC_OFF"){
            actionTransmitter.sendSignal(1,'C',false);
            LampC_Status=0;
            iosController.writeMessage("LampC",LampC_Status);
          }
        
          else if (readString == "lampD_ON"){
            actionTransmitter.sendSignal(1,'D',true);
            LampD_Status=1;
            iosController.writeMessage("LampD",LampD_Status);
          }
        
          else if (readString == "lampD_OFF"){
            actionTransmitter.sendSignal(1,'D',false);
            LampD_Status=0;
            iosController.writeMessage("LampD",LampD_Status);
          }
        
          else if (readString == "lampE_ON"){
            actionTransmitter.sendSignal(1,'E',true);
            LampE_Status=1;
            iosController.writeMessage("LampE",LampE_Status);
          }
        
          else if (readString == "lampE_OFF"){
            actionTransmitter.sendSignal(1,'E',false);
            LampE_Status=0;
            iosController.writeMessage("LampE",LampE_Status);
          }
        } //end optimize if 'lamp' 
        
        else if (readString == "Vertrekken"){ //translation: Leave the building ;)
          MsTimer2::stop(); //Mstimer2 stop. Otherwise DelayedBedtijd() would be called every 60 sec.     
          iosController.writeMessage("NaarBed",0);
        
          actionTransmitter.sendSignal(1,'E',false);
          LampE_Status=0;
          iosController.writeMessage("LampE",LampE_Status);
          
          actionTransmitter.sendSignal(1,'D',false);
          LampD_Status=0;
          iosController.writeMessage("LampD",LampD_Status);
          
          actionTransmitter.sendSignal(1,'C',false);
          LampC_Status=0;
          iosController.writeMessage("LampC",LampC_Status);
          
          actionTransmitter.sendSignal(1,'B',false);
          LampB_Status=0;
          iosController.writeMessage("LampB",LampB_Status);
          
          actionTransmitter.sendSignal(1,'A',false);
          LampA_Status=0;          
          iosController.writeMessage("LampA",LampA_Status);
        }
        
        else if (readString == "Opstaan"){ //translation: get out of bed ;-)
          MsTimer2::stop(); //Mstimer2 stop. Otherwise DelayedBedtijd() would be called every 60 sec.     
          iosController.writeMessage("NaarBed",0);
         
         // Uncomment to also turn LampE on. 
        //  actionTransmitter.sendSignal(1,'E',true);
        //  LampE_Status=1;
        //  iosController.writeMessage("LampE",LampE_Status);
          
          actionTransmitter.sendSignal(1,'D',true);
          LampD_Status=1;
          iosController.writeMessage("LampD",LampD_Status);
          
          actionTransmitter.sendSignal(1,'C',true);
          LampC_Status=1;
          iosController.writeMessage("LampC",LampC_Status);
          
          actionTransmitter.sendSignal(1,'B',true);
          LampB_Status=1;
          iosController.writeMessage("LampB",LampB_Status);
          
          actionTransmitter.sendSignal(1,'A',true);
          LampA_Status=1;          
          iosController.writeMessage("LampA",LampA_Status);
        } 
        
        else if(readString == "Bedtijd"){
          iosController.writeMessage("NaarBed",1);
          MsTimer2::set(60000, DelayedBedtijd); // 60.000ms period
          MsTimer2::start(); 
          //
        }

        
       
        if(no_SendSwitchStatus == 0) //if it's 1 then an update of switch status is not necessary
           delay(200); //maybe this helps ;-)
           sendSwitchStatus(); //Send the switch status each time a command has been received
        no_SendSwitchStatus = 0;
        
     RemoteReceiver::enable(); //reenable the 434mhz receiver (of the remote switch library) again.
  
//Don't put serial.print debug lines in this function. Don't ask why, but it crashes in that case!
}


void DelayedBedtijd(){  // delayed activation of 'Bedtijd'
       
        RemoteReceiver::disable();//disable the remote receiver
        
        MsTimer2::stop(); //Mstimer2 stop. Otherwise DelayedBedtijd() would be called every 60 sec.     
        iosController.writeMessage("NaarBed",0);
       
          actionTransmitter.sendSignal(1,'E',false);
          LampE_Status=0;
          iosController.writeMessage("LampE",LampE_Status);
          
          actionTransmitter.sendSignal(1,'D',false);
          LampD_Status=0;
          iosController.writeMessage("LampD",LampD_Status);
          
          actionTransmitter.sendSignal(1,'C',false);
          LampC_Status=0;
          iosController.writeMessage("LampC",LampC_Status);
          
          actionTransmitter.sendSignal(1,'B',false);
          LampB_Status=0;
          iosController.writeMessage("LampB",LampB_Status);
          
          actionTransmitter.sendSignal(1,'A',false);
          LampA_Status=0;          
          iosController.writeMessage("LampA",LampA_Status);
        
        sendSwitchStatus(); //Send the switch status each time a command has been received
         
        RemoteReceiver::enable(); //enable the remote receiver.
}

void TX434Send(String tx_message){  //send string over 434Mhz
  
          char msg[tx_message.length()+1];
          tx_message.toCharArray(msg,tx_message.length()+1);
          digitalWrite(PTT_PIN, true); //Led On
          if(vw_send((uint8_t *)msg, strlen(msg))); //zend data, True als bericht accepted is.
          vw_wait_tx(); // wait until message has been send.
          delay(200); //wait for message being send.
          Serial.println("TX434 message send");
          digitalWrite(PTT_PIN, false); //Led Off
}
