/*
Domotica Gateway by Alexander van der Sar - www.vdsar.net
this device is a connection hub between internet, other Arduino's or Raspberry PI('s).
Relays, wireless transmitters or other sensors or output device can be connected to this device.

The device listens on a ethernet port for commands to be executed. Commands switches digital ports,
read analog data or send wireless data. Anything can be programmed in this device. 



Changelog:
v0.1 - 10 october 2012 - the initial version using ethernet and switch basic devices
v0.2 - 12 october 2012 - added Arduino Manager using IOSController.h (v1.5.1 minimal) (buy from iStore). Added support for iOS and MAC OS control. Split in multiple files
v0.2a - 20 october 2012 - added minor delay of 2 seconds in ProcessMessage to reduce overhead in sending data to iOS.
v0.2b - 20 october 2012 - added 'bedtijd' delayed turn off lights using MsTimer2.h library
v0.2c - 20 october 2012 - added sync of switches for iOS devices
v0.3 - 21 october 2012 - added 434Mhz Receiver. This will receive commands from the 434mhz remotes and trigger the commands in the Arduino which will send commands 
        via 434mhz to the receivers. Goal is better reach of the remotecontrols and now the Arduino always knows the state of the switches
        with the assumption that if you press a button on the remote and a light does not switch on, you repeat this action. 
0.4 - 21 october 2012 - added ToLCD file with function to transfer switch status to LCD display. (in progress)
0.4a - 23 october 2012 - added receiver to interface remote controlling.
0.4b - 23 october 2012 - added iOS message update to update switch status when using remote control
0.4c - 26 october 2012 - added timing millis() to monitor speed
0.4d - 27 october 2012 - optimized if statements
0.4e - 27 october 2012 - more IF optimazations and cleanup
0.5 - 27 october 2012 - clean up of unnecessary Serial.print commands that crashed the code, check the code for use of interrupts(); 
0.5c - 12 november 2012 - Added functionality for receiving VARIABLES like moonrise e.d.
0.5d - 12 november 2012 - created TX434send function to send data
0.5e - 13 november 2012 - optimzed code with TX434 Send, added delay to TX434Send to give receiver some slack and added
      sunmoon data transfer to standard TX434
0.5f - 19 november 2012 - Since v020 of LCDDisplay_434mhz, it is necessary to close received strings with a comma (like domo,2343, )
0.6 - 2 december - Implemented new format in which data is received from the environment 
      (TX434=v1,value,value,value instead of TX434=Variable,value,variable,value. Make it more efficient"
      
      
ToDO: Prowl API library toevoegen met alarmering

Variable string to LCD display:
V1,actual,today,peak,total,
V2,TotalActual,Nactual,NactualReturn,GasUsage,

*/

#define VERSION "V0.6 - Domotica Gateway - www.vdsar.net"
#include <RemoteTransmitter.h>
#include <RemoteReceiver.h>
#include <MsTimer2.h>
#include <VirtualWire.h>

#include <SPI.h>

#include <Dhcp.h>
#include <Dns.h>
#include <Ethernet.h>
#include <EthernetClient.h>
#include <EthernetServer.h>
#include <EthernetUdp.h>
#include <util.h>
#include <SD.h>
#include <IOSController.h>




int iOS_Port = 12345; //change to whatever you like to us as incoming port for iOS controller (Arduino manager)
int MyServer_Port = 55; //change to whatever you like to use for other incomming connections (i.e. 23 for telnet)



 // the media access control (ethernet hardware) address for the shield:
byte mac[] = { 0xDE, 0xAE, 0xAE, 0xEF, 0xFE, 0xED };  
//the IP address for the shield:
byte ip[] = { 192, 168, 1, 14 };  // change to whatever you want it to be (also modify this in Energy meter code)  
// the router's gateway address:
byte gateway[] = { 192, 168, 1, 1 };
// the subnet:
byte subnet[] = { 255, 255, 255, 0 };

// telnet defaults to port 23
EthernetServer server = EthernetServer(iOS_Port); //iOS Server
EthernetServer myserver = EthernetServer(MyServer_Port); //ethernet (telnet like) server


//Define Strings & Pins

String readString; //String read from network
String TX_Message; //message to be transfered to LCD display
String TX_Message2; //2nd message used for sending domo switch status to lcd
String Text[11]={"","","","","","","","","","",""};

int actual;
int peak;
int today;
int total;
int TotalActual;
int Nactual;
int NactualReturn;
float GasUsage;


unsigned long int prev_millis;
  
int PTT_PIN = 13; // Led on when 434mhz starts transmitting
int TX_PIN = 12; // TX pin of 434 mhz transmitter
int RX_INTERRUPT = 1; // Interrupt 0 = pin 2 for RX pin of 434 mhz receiver (using interrupt)

int RELAY1 = 42;  // Relays for gardenlights
int RELAY2 = 44;
int RELAY3 = 46;
int RELAY4 = 48; 

boolean LampA_Status=0; //status for remotecontrolled switches. Unreliable but when switched by this program, status is updated.
boolean LampB_Status=0;
boolean LampC_Status=0;
boolean LampD_Status=0;
boolean LampE_Status=0;
boolean LampF_Status=0;
boolean DeurAchter_Status=0;
boolean TuinAchter_Status=0;

long DomoStatus=0;
boolean no_SendSwitchStatus=0;




ActionTransmitter actionTransmitter(TX_PIN);
ElroTransmitter elroTransmitter(TX_PIN);
//KaKuTransmitter kaKuTransmitter(TX_PIN);
//BlokkerTransmitter blokkerTransmitter(TX_PIN);

/*
 * Prototypes of IOSController’s callbacks
 *
 */
void doWork();
void doSync(char *variable);
void processIncomingMessages(char *variable, char *value);
void processOutgoingMessages();
void processAlarms(char *variable);
void deviceConnected();
void deviceDisconnected();


/*
 * IOSController Library initialization
 */
#ifdef ALARMS_SUPPORT 
  IOSController iosController(&server,&doWork,&doSync,&processIncomingMessages,&processOutgoingMessages,&processAlarms,&deviceConnected,&deviceDisconnected);
#else
  IOSController iosController(&server,&doWork,&doSync,&processIncomingMessages,&processOutgoingMessages,&deviceConnected,&deviceDisconnected);
#endif

 


void setup(){
 Serial.begin(9600);
 Serial.println("Starting Domotica Gateway");
 Serial.println(VERSION);
    // initialize the ethernet device
  Ethernet.begin(mac, ip, gateway, subnet);
  // start listening for clients
  server.begin();
  
  //setup VirtualWire op 434 Mhz zender
  vw_set_tx_pin(TX_PIN);
  vw_setup(2000); //virtual wire bits per sec 
  
   // Initialize receiver on interrupt 0 (= digital pin 2), calls the callback "showCode"
  // after 3 identical codes have been received in a row. (thus, keep the button pressed
  // for a moment)
  //
  // See the interrupt-parameter of attachInterrupt for possible values (and pins)
  // to connect the receiver.
  RemoteReceiver::init(RX_INTERRUPT, 3, ReceiveRemoteControl);
  
  
  pinMode(PTT_PIN, OUTPUT); 
  pinMode(RELAY1, OUTPUT);
  pinMode(RELAY2, OUTPUT);
  pinMode(RELAY3, OUTPUT);
  pinMode(RELAY4, OUTPUT);
  
  //relays work inversed. False = on, true = off. Switch them off at start of Arduino
  digitalWrite(RELAY1,true);
  digitalWrite(RELAY2,true);
  digitalWrite(RELAY3,true);
  digitalWrite(RELAY4,true);
}

void loop(){
//only call iosController loop. ALL regular work goes into doWork() function instead of loop!

  iosController.loop(450);

 }

void doWork(){  //This is the IOSController 'replacement' for the arduin loop() function.

  // if an incoming client connects, there will be bytes available to read:
 
  EthernetClient myclient = myserver.available();
  
  
  if (myclient){
    //Serial.print("Connected myclient on port: ");
    //Serial.println(MyServer_Port);
    
    while (myclient.available()) { //as long as data is available to read
        char c = myclient.read();
        readString += c;
     }
   
   readString.trim(); //remove whitespaces from created readString. 
   Serial.print("readString == ");
   Serial.println(readString); //for debugging
   
   StartSwitching(readString);
   
   readString = ""; //clean readString to receive new command via network
     
  
    if (!myclient.connected()) {
      myclient.stop();  
      //Serial.print("Disconnected myclient on port: ");
      //Serial.println(MyServer_Port);
      }
  } 
}






void doSync (char *variable) {
/*
  if (strcmp(variable,"Knob1")==0) {

    iosController.writeMessage(variable,map(servo.read(),0,180,0,1023));
  }
*/

// When adding a new variable (like LampF or so, also add it to the controlling file to immediately update iOS switch)
  if (strcmp(variable,"TuinVoor")==0) 
    iosController.writeMessage(variable,!digitalRead(RELAY1)); //true == off, false == on
  
  else if (strcmp(variable,"TuinMidden")==0) 
    iosController.writeMessage(variable,!digitalRead(RELAY2));
    
  else if (strcmp(variable,"DeurRechts")==0) 
    iosController.writeMessage(variable,!digitalRead(RELAY3));
   
  else if (strcmp(variable,"DeurLinks")==0) 
    iosController.writeMessage(variable,!digitalRead(RELAY4));
  
    else if (strcmp(variable,"LampA")==0) 
    iosController.writeMessage(variable,LampA_Status);
  
    else if (strcmp(variable,"LampB")==0) 
    iosController.writeMessage(variable,LampB_Status);
  
    else if (strcmp(variable,"LampC")==0) 
    iosController.writeMessage(variable,LampC_Status);
  
    else if (strcmp(variable,"LampD")==0) 
    iosController.writeMessage(variable,LampD_Status);
  
    else if (strcmp(variable,"LampE")==0) 
    iosController.writeMessage(variable,LampE_Status);
  
    else if (strcmp(variable,"TuinAchter")==0) 
    iosController.writeMessage(variable,TuinAchter_Status);
  
    else if (strcmp(variable,"DeurAchter")==0) 
    iosController.writeMessage(variable,DeurAchter_Status);  
 
}



/**
*
*
* This function is called periodically and messages can be sent to the iOS device
*
*/
void processOutgoingMessages() {

  
  if(millis() - 2500 >= prev_millis){  // eens per 2,5 seconden de waarden updaten naar iOS.
  iosController.writeMessage("Actual",actual);
  iosController.writeMessage("Peak", peak);
  iosController.writeMessage("Today", today);
  iosController.writeMessage("Total", total);
  iosController.writeMessage("Consumption", TotalActual);
  iosController.writeMessage("Import", Nactual);
  iosController.writeMessage("Export", NactualReturn);
  iosController.writeMessage("GasUsage", GasUsage);
    
      
  prev_millis = millis(); 
  }
   

}

/**
*
*
* This function is called when a Alarm is fired
*
*/
void processAlarms(char *alarm) {
  
  Serial.print(alarm);
  Serial.println(" fired");
  
}

/*
*
* This function is called when the iOS device connects
*/
void deviceConnected () {

 Serial.println("iOS Device Connected");
}

/**
*
* This function is called when the iOS device disconnects
*/
void deviceDisconnected () {

  Serial.println("iOS Device Disconnected");
}

  

    

