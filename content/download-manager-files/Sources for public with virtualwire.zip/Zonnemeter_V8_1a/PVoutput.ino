void SendToPvOutput(Solar S)
{
    if(S.SID > 0) // only output to enabled System
    {
        pvoutput(S.SID, S.Today, S.Peak);
    }
}


void pvoutput(int sid, long today, long peak)
{
    EthernetClient pvout;
    if (pvout.connect("pvoutput.org",80))
    {
       // pvoutputok = true;
        logFile << sid << ": ";
        pvout << F("GET /service/r2/addstatus.jsp");
        pvout << F("?key=" PVOUTPUT_KEY);
        pvout << F("&sid=") << sid;
        sprintf(webData, "&d=%04d%02d%02d", year(),month(),day());
        pvout << webData;
        sprintf(webData, "&t=%02d:%02d", hour(),minute());
        pvout << webData;
        pvout << F("&v1=") << today;
        pvout << F("&v2=") << peak;// k << endl; //(endl weghalen als slimme meter erbij komt
        //pvout << F("&v3=") << Ntoday;
        pvout << F("&v3=") << TotalToday;
        // pvout << F("&v4=") << Npeak; // << endl;
        pvout << F("&v4=") << TotalPeak;
              
        //The gas outputs are not yet completely what I want it to be.       
        pvout << F("&v7=") << GasUsage << endl; //v7 and v8 are only available when you donate a small amount of money to pvoutput.org!
        if(GasUpdateFlagPVout == 1){
          pvout << F("&v8=") << GasUsageLastHour << endl;
          GasUpdateFlagPVout = 0;
        }
        pvout << F("Host: pvoutput.org") << endl << endl;
        
         // read the response code. 200 means ok
        pvResponse = pvout.parseInt();
        pvout.flush();
        pvout.stop();
        // give pvoutput some time to process the request
        delay(200);
    }
    else
    {
        pvResponse=0;
        logFile << F("Cannot connect") << endl; //niet in 8.3 van harold, misschien nog verwijderen
    }
}

 
