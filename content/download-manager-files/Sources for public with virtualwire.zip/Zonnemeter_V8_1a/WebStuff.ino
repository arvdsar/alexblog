const int maxLength = 25;
String inString = String("");
// storage for last page access


void ServeWebClients() 
{
    EthernetClient client = server.available();
    int i;
    if (client) 
    {
      inString = client.readStringUntil('\n');
      client << F("HTTP/1.1 200 OK") << endl;
      client << F("Content-Type: application/x-javascript") << endl << endl;
      i=inString.indexOf("?");
      if(i!=-1) readValue(inString,i);
      showStatus(client);
      client.stop();
    }
}

void readValue(String input,int i)
{
    long val=0;
    bool neg=false;
    int j=i+3;
    int address = input[i+1]-'0';
    if(address>=0 && address<15)
    {
        char c=input[j];
        if(c=='-')
        {
           neg=true;
           j++;
           c=input[j];
        }
        while(c>='0' && c<='14')
        {
           val = 10*val + (c-'0');
           j++;
           c=input[j];
        }
        if(neg) val=-val;
        writelong(address,val);
    }
}

void showStatus(EthernetClient client)
{
    int i;
    client << DateTime(now()) << endl;
    client << F(VERSION) << endl;

    solarStatus(client, S1);
    solarStatus(client, S2);
  //  solarStatus(client, S3);
   
    
        client << F("LichtNet Actual Import: ") << Nactual << " W" << endl; //grid actual import
        client << F("LichtNet Today Import: ") << Ntoday << " Wh" << endl; //grid import today
        client << F("LichtNet Peak Import: ") << Npeak << " W" << endl << endl; //grid peak import (max actual value in 5 minutes)
        
        client << F("Teruglevering Actual: ") << NactualReturn << " W" << endl; // export actual
        client << F("Teruglevering Today: ") << NtodayReturn << " Wh" << endl; //export toay
        client << F("Teruglevering Peak: ") << NpeakReturn << " W" << endl << endl; // export peak
        
        client << F("Energie verbruik Today (lichtnet+zon): ") << TotalToday << " Wh" << endl; //energy consumption today
        client << F("Netto Import LichtNet (Opname - teruglevering) today: ") << NetToday << endl << endl; //net import from gid today
        
        client << F("Energie verbruik Peak: ") <<TotalPeak << endl; //energy consumption peak
        client << F("Energie verbruik Actual: ") << TotalActual << endl; //energy consumption actual
        client << F("Energie verbruik Gemiddeld Actual: ") << TotalActualAverage << endl; //energy consumption average actual (two actual readings)

        client << F("Gasverbruik Today: ") << GasUsage << endl; //gas usage today
        client << F("Gasverbruik last hour: ") << GasUsageLastHour << endl; //gas usage during last hour
        client << F("Inleestijd Gasverbruik: ") << GasReadTime << endl << endl; //timestamp of reading gas value from smart meter
    
    
    client << F("Eeprom:") << endl;  
    for(i=0;i<10;i++)
    {
      client << i << " : " << readlong(i) << endl;
    }

   client << F("PvOutput response: ") << pvResponse << endl;
   client << F("CosmOutput response: ") << cosmResponse << endl;


}


void UpdateLCD(){
  
  Serial.println("updateLCD function called");
  EthernetClient DomoticaClient;          // client to connect to Domotica Box

 if(!DomoticaClient.connected()){
  // Serial.println("Domoticabox not yet connected!");
   if(DomoticaClient.connect(DomoticaBoxIP, DomoticaBoxPort))
    // Serial.println("connecting...");
     if(DomoticaClient.connected()){
      // Serial.println("DomoticaBox is CONNECTED ;-)");
       showStatusLCD(DomoticaClient, S1); 
     }
  /*   else 
       Serial.println("DomoticaBox cannot connect");
    */ 
 }
     else {
      // Serial.println("DomoticaBox still connected");
       showStatusLCD(DomoticaClient,S1);
     }
 
 DomoticaClient.stop(); //disconnect DomoticaBox. Seems that each time new connection is created.
}



void showStatusLCD(EthernetClient DomoticaClient, Solar S) //Send string to domoticabox for LCD display
{
   if(S.SID>0) 
  {  //virtualwire limit is 27 bytes per transmission (TX434= will be removed by DomoticaClient so only V1.... will be send)
  DomoticaClient.print("TX434=V1,"); //Solar Actual
  DomoticaClient.print(S.Actual);
  DomoticaClient.print(",");
  DomoticaClient.print(S.Today); //Solar Today
  DomoticaClient.print(",");
  DomoticaClient.print(S.Peak);
  DomoticaClient.print(","); // Solar Total
  DomoticaClient.print(S.Total/1000);
  DomoticaClient.println(",");
  delay(1000);
  DomoticaClient.print("TX434=V2,"); //Net import Actual
  DomoticaClient.print(TotalActual);
  DomoticaClient.print(","); //Net export actual
  DomoticaClient.print(Nactual);
  DomoticaClient.print(",");
  DomoticaClient.print(NactualReturn);
  DomoticaClient.print(",");
  DomoticaClient.print(GasUsage);
  DomoticaClient.println(",");

    
  delay(500); //Idle time to give some slack to process data (maybe it can be removed)
  }
}


void solarStatus(EthernetClient client, Solar S)
{
    if(S.SID>0)
    {
        client << S.SID << endl;
        client << F("Actual: ") << S.Actual << endl;
        client << F("Today: ") << S.Today << endl;
        client << F("Total: ") << S.Total << endl; 
        client << F("Peak: ") << S.Peak << endl << endl;
    }
}

char* DateTime(time_t t)
{
    int y = year(t)-2000;
    if(y < 0) sprintf(webData,"Invalid");
    else      sprintf(webData, "%02d.%02d.%02d %02d:%02d:%02d", day(t),month(t),y,hour(t),minute(t),second(t));
    return webData;
}
