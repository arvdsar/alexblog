//*****************************************************************
//*                                                                
//*  userdefines                                                   
//*****************************************************************
#ifndef userdefs_h
#define userdefs_h

#define PROWLAPI_KEY "YOUR PROWL APP KEY HERE" //www.prowlapp.com
#define PVOUTPUT_KEY "YOUR PVOUTPUT API KEY HERE" //www.pvoutput.org

//www.cosm.com
#define COSMAPIKEY         "YOUR COSM API KEY HERE" // replace your pachube api key here
#define COSMFEEDID         12345 // replace your feed ID
#define COSMUSERAGENT      "Energy Monitor" // user agent is the project name (you can replace this)

// Every output has it's own system ID. Set to 0 if not used
static int SID1 = ;  //Replace with your PVOUTPUT ID
static int SID2 = 0; //another one if you have 2 solar systems
//static int SID3 = 0;

// Network variables
static byte mac[] = { 0xAE, 0xBD, 0xBE, 0xAA, 0xDE, 0xDE }; // MAC address change it a little by replacing the two characters past 0x (so 0xAE, replace AE) with a number 0-9 or letter A-F
static byte ip[] = { 192, 168, 1, 13 }; // IP addres of arduino, replace with one that suits you (depending on your network)
static byte gateway[] = { 192, 168, 1, 1 }; //gateway ip adres
static byte subnet[] = { 255, 255, 255, 0 };
static byte dnsserver[] = { 192, 168, 1, 1 }; //

static byte DomoticaBoxIP[] = { 192, 168, 1, 14 }; //IP Addres of DomoticaBox (
static int DomoticaBoxPort = 55;  //port on which the domoticabox listens (could make it 23 if you want telnet to work with it too)

#endif
