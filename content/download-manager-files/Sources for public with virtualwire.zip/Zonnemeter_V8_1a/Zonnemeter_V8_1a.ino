/* 
Credits for the base code are for Harold65 who wrote a nice program http://solarmeter.codeplex.com/
Credits go to many other people for providing libraries. You'll find the libraries when searching on google.

Wishlist:
- Store data on mysqldatabase on Raspberry Pi
- add watchdog?

*ChangeLog
V5.1 - 5ms timer interrupt. S2 & S3 disabled
V5.2 - none
V5.3a - Added UpdateLCD function to send data to DomoticaBox which updates portableLCD display
V5.3b - added comma as seperator in data send to DomoticaBox
V5.3c - added transmit of TotalPwr
V5.3f - added more frequent update of actual details 
V7.0a - original V7.0 from harold65 updated with changes of V5.3f
V7.1a - met serieel uitlezen slimme meter
V7.2 - Werkende versie met slimme meter & pvoutput update. (gas to do)
V7.3 - Slimme meter Electra + Gas, incl upload naar PvOutput (gas als parameter v7=) helaas nog niet te vinden op PVoutput.
      Also, removed S3 (3rd Solar system, to save some EEPROM space. )
V7.3a - used TotalToday instead of Ntoday for upload consumption to PVOutput      
V7.4 - Added Prowl alerts and added TotalActualAverage to use two power readings of actual to reduce peaks a little.
V7.6 - added upload to Cosm (working with limited variables for some reason)
V7.7 - Gas usage per hour, changed Timeserver address making sketch start much faster. 
V8.0 - Added some fixes found in Harold65 version 8.3:
      - check PVoutput and Cosm responsecode after uploading
      - changed timeserver IP address to nl.pool.ntp.org
      - Changed ServeWebClients() function to use harold65 version 8.3 
V8.1 - Changed data string send to Domoticagateway 
        Variable string to LCD display:
        V1,actual,today,peak,total,
        V2,TotalActual,Nactual,NactualReturn,GasUsage,
        STABLE VERSION!
V8.1a - translated some dutch text to english and move some user specific details to userDefs.

*/

#define VERSION "V8.1a - EnergyBox with DomoticaBox & Smartmeter"

#include <SPI.h>
#include <Ethernet.h>
#include <EthernetUdp.h>
#include <Time.h>
#include <SD.h>
#include <FlashMini.h>
#include <MsTimer2.h>
#include <avr/eeprom.h>
#include <Avviso.h>
#include <HTTPClient.h>

#include "Userdefs.h"
#include "Solar.h"



// define eeprom addresses
#define EE_S1_TOTAL 0
#define EE_S1_TODAY 1
#define EE_S2_TOTAL 2
#define EE_S2_TODAY 3
#define EE_N1_GAS 4 //gas at 0.00 hr
//#define EE_N1_GASHR 5 // gas at past hour.
#define EE_N1_M1 6
#define EE_N1_M2 7
#define EE_N1_M3 8
#define EE_N1_M4 9





// Construct a class for each sensor
Solar S1(2,SID1);
Solar S2(3,SID2);
//Solar S3(4,SID3);

// global variables
int    lastDay;
int    lastHour;
int    lastMinute;
volatile long   updateActualCounter=0; //om elke x seconden de actuals te updaten.
//bool   pvoutputok = false
int    pvResponse;
int cosmResponse;
//bool   cosmok = false;
EthernetServer server(80);              // the web server is used to serve status calls
char   webData[70];
File   logFile;
EthernetUDP Udp;


// int incomingByte = 0;

#define MeterInterval  10000  // Read Smart Meter values only once per 10
unsigned long previousMillis;
boolean sendMeter = true;



//initialize Meterstanden
long M1=0; 
long M2=0;
long M3=0;
long M4=0;
long M1tmp=0;  //variable to store the meterstand at midnight
long M2tmp=0;
long M3tmp=0;
long M4tmp=0;
long GAS=0;
long GAStmp=0;

long GasMeter = 0;
float GasUsage = 0;
float GasUsageLastHour = 0;
long GasReadDate = 0;
long GasReadTime = 0;
long GasReadTime_Prev = -1;
long GasReadDate_Prev = 0;
//float GasUsageFl = 0;
long GasPrev = 0;
boolean GasUpdateFlagPVout = 0;
boolean GasUpdateFlagCosm = 0;

long   Nactual = 0; //actual power consumption FROM NET
long   NactualReturn = 0; //actual power delivery from solar TO NET (as in 'teruglevering')
long   NpeakReturn = 0; //peak power delivery from solar to Net (as in teruglevering) 
long NtodayReturn=0; //dag teruglevering (M3+M4) - (M3tmp+M4tmp)
long Ntoday=0; //dag verbruik (M1+M2) - (M1tmp+M2tmp)
long Ngas=0;
long Npeak=0;
long NetToday=0; //usage from energygrid
long TotalToday=0; //total usage (solar & energygrid)
long TotalPeak=0;
long TotalActual=0;
long TotalActualtmp=0;
long TotalActualAverage=0;

boolean Notified_A=0; //prowl notification 
boolean Notified_B=0; //another prowl notification

void setup()
{
    Serial.begin(9600);
    Serial1.begin(9600,SERIAL_7E1); //initialize serial port 1 on Arduino Mega for Smart Meter P1 port 
       
    pinMode(4, OUTPUT); // RTC pin for P1 Port 
    digitalWrite(4, HIGH); // RTC pin HIGH for start serial data transfer P1 (one Pin is high, every 10 seconds a dump is send by P1)
  
    // initialize network
    Ethernet.begin(mac, ip, dnsserver, gateway, subnet); //was (mac, ip, dnsserver)
    // initialize time server
    Udp.begin(8888);
    // wait until time is set
    Serial.println("start tijd bijwerken");
    while(!UpdateTime());
    Serial.println("Tijd bijgewerkt");
    // initialize SD card
    SetupSD();
    OpenLogFile();
    // start listening
    server.begin();
    // initialize counters
    S1.begin();
    S2.begin();
    //S3.begin();
    lastDay = day();
    lastMinute = minute();
    lastHour = hour();
    // restore the last saved values
    S1.Total = readlong(EE_S1_TOTAL);
    S1.Today = readlong(EE_S1_TODAY);
    // Total was saved at midnight so we have to add todays production
    S1.Total += S1.Today;
    
    S2.Total = readlong(EE_S2_TOTAL);
    S2.Today = readlong(EE_S2_TODAY);
    S2.Total += S2.Today;
    
   // S3.Total = readlong(EE_S3_TOTAL);
   // S3.Today = readlong(EE_S3_TODAY);
   // S3.Total += S3.Today;
    
    //Smart Meter info (Mxtmp is the meterstand at midnight 0:00)
    M1tmp = readlong(EE_N1_M1);
    M2tmp = readlong(EE_N1_M2);
    M3tmp = readlong(EE_N1_M3);
    M4tmp = readlong(EE_N1_M4);
    GAStmp = readlong(EE_N1_GAS);
    
    UpdateLCD(); //initiele waarden op LCD tonen bij starten Solar Monitor
    
  // To use Notify My Android instead of Prowl, use this line:
  //Avviso.begin(NOTIFY_MY_ANDROID);
  // and comment out this begin line:
  Avviso.begin();
  // For Prowl, go to
  //   https://www.prowlapp.com/api_settings.php
  // to create an API key.
  // For Notify My Android, go to
  //   https://www.notifymyandroid.com/account.jsp
  // to create an API key.
  // If you don't, the server will return a 401 error code.
  Avviso.setApiKey(PROWLAPI_KEY);
  Avviso.setApplicationName("Energy Monitor");
    
    
    // start the timer interrupt
    MsTimer2::set(5, Every5ms); // 5ms period
    MsTimer2::start();
}

// check and update all counters every 5ms.
void Every5ms()
{
    S1.CheckSensor();
   // S2.CheckSensor();
   // S3.CheckSensor();
}

void loop()
{   
    // reset counters at midnight
    if(day()!=lastDay && lastHour==23)
    {
        lastDay=day();
        // save the total counters
        writelong(EE_S1_TOTAL,S1.Total);
        writelong(EE_S2_TOTAL,S2.Total);
     //   writelong(EE_S3_TOTAL,S3.Total);
        S1.NewDay();
        S2.NewDay();
     //   S3.NewDay();
        
        //smart meter new day
        //save meterstand at midnight for this day
        writelong(EE_N1_M1,M1);
        writelong(EE_N1_M2,M2);
        writelong(EE_N1_M3,M3);
        writelong(EE_N1_M4,M4);
        writelong(EE_N1_GAS,GAS);
        
        //save meterstanden at midnight for this day to tmp variables for calculations.
        M1tmp=M1;
        M2tmp=M2;
        M3tmp=M3;
        M4tmp=M4;
        GAStmp=GAS;
        
        
        // create new logfile
        CloseLogFile();
        OpenLogFile();
    }

    if(hour()!=lastHour)
    {
      Notified_A = 0; //reset notification A (near max current reached (see file Notifications)  
      lastHour=hour();
        // save the daily values every hour
        writelong(EE_S1_TODAY,S1.Today);
        writelong(EE_S2_TODAY,S2.Today);
   //     writelong(EE_S3_TODAY,S3.Today);
	// sync the time at fixed interval
	if(lastHour==10 || lastHour==22)
        {
          UpdateTime();
        }
    }

   //Update actuals every 20 seconds (value * 5 msec) (Reuse the 5Ms timer)
   if(updateActualCounter > 4000){ //update actualpower every 20 seconds
     updateActualCounter = 0;
     S1.CalculateActual();
     UpdateLCD();
    }
    // update every minute
    if(minute()!=lastMinute)
    {
        lastMinute=minute();
        S1.CalculateActual();
        S2.CalculateActual();
    //    S3.CalculateActual();
        updateActualCounter = 0;
        UpdateLCD(); //update data on wireless LCD via Domotica Box
        
        WriteDateToLog();
        logFile << S1.Total << ";" << S1.Actual << ";" << endl;
        logFile << S2.Total << ";" << S2.Actual << ";" << endl;
     //   logFile << S3.Total << ";" << S3.Actual << ";" << endl;
       

        
        if((lastMinute%5)==0)
        {
           

            Notified_B = 0; //reset Notification B (More than Max Current reached, see file: "Notifications")  
          // PvOutput can handle 1 event per 5 minutes (per system)
            SendToPvOutput(S1);
            SendToPvOutput(S2);
     //       SendToPvOutput(S3);
     
            cosm(); //send values to COSM.COM (not very reliable :(

            // reset the maximum for pvoutput
            S1.ResetPeak();
            S2.ResetPeak();
     //       S3.ResetPeak();  
            
            Npeak = 0; //reset the maximum for pvoutput. (Npeak = Power usage from Net)
            NpeakReturn = 0; //reset the max export peak
            TotalPeak=0;
            
            logFile.flush();          
        }
    }
   
    // see if there are clients to serve
    ServeWebClients();
    delay(50);
    
    if (millis() > (previousMillis + MeterInterval)) {
      sendMeter = true ;
      previousMillis = millis();
    }
     ReadSmartMeter(); //uitlezen smart meter aanroepen
     Alarms(); //check values to determine if notifications to Prowl are necessary
      
}





