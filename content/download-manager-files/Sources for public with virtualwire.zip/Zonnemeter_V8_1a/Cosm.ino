
/*
  Pachube sensor client (COSM.COM)
 
 created 15 March 2010
 modified 9 Apr 2012
 by Tom Igoe with input from Usman Haque and Joe Saavedra
 
http://arduino.cc/en/Tutorial/PachubeClient
 This code is in the public domain.
 
 */



// if you don't want to use DNS (and reduce your sketch size)
// use the numeric IP instead of the name for the server:
//IPAddress server(216,52,233,122);      // numeric IP for api.pachube.com
//char server[] = "api.pachube.com";   // name address for pachube API


// this method makes a HTTP connection to the server:
void cosm() {
  EthernetClient cosm;
  // if there's a successful connection:
  if (cosm.connect("api.cosm.com", 80)) {
//cosmok = true;

    Serial.println("connecting to Cosm.");
    // send the HTTP PUT request:
    cosm.print("PUT /v2/feeds/");
    cosm.print(COSMFEEDID);
    cosm.println(".csv HTTP/1.1");
    cosm.println("Host: api.pachube.com");
    cosm.print("X-PachubeApiKey: ");
    cosm.println(COSMAPIKEY);
    cosm.print("User-Agent: ");
    cosm.println(COSMUSERAGENT);
    cosm.print("Content-Length: ");

    // calculate the length of the sensor reading in bytes:
    // 8 bytes for "sensor1," + number of digits of the data:
   // int thisLength = 124 + getLength(S1.Today) + getLength(S1.Total)
   // +getLength(S1.Peak)+getLength(Npeak) + getLength(NpeakReturn) + getLength(Ntoday)
   // +getLength(TotalToday)+getLength(TotalPeak)+getLength(GasUsage);
    
    int thisLength = 42 + getLength(TotalToday) + getLength(TotalPeak) + getLength(GasUsage);
    
    cosm.println(thisLength);

    // last pieces of the HTTP PUT request:
    cosm.println("Content-Type: text/csv");
    cosm.println("Connection: close");
    cosm.println();

    // here's the actual content of the PUT request:
   
  //  cosm.print("SolarToday,"); //11
 //   cosm.println(S1.Today);
   // cosm.print("SolarLifetime,"); //14
   // cosm.println(S1.Total);
   // cosm.print("SolarPeak,"); //10
   // cosm.println(S1.Peak);
   // cosm.print("PeakImport,"); //11
   // cosm.println(Npeak);
   // cosm.print("PeakExport,"); //11
   // cosm.println(NpeakReturn);
    //cosm.print("TodayImport,"); //12
   // cosm.println(Ntoday);
    cosm.print("GasUsage,"); //9
    cosm.println(GasUsage);  
         if(GasUpdateFlagCosm == 1){
            cosm.print("GasHour,");
            cosm.println(GasUsageLastHour);
            GasUpdateFlagCosm = 0;
        }
    cosm.print("ConsumptionToday,"); //17
    cosm.println(TotalToday);
    cosm.print("ConsumptionPeak,"); //16
    cosm.println(TotalPeak);

  
  //oude versie 7.7 code
  /*
    delay(1000);
    cosm.stop(); 
  }
  else {
    // if you couldn't make a connection:
    cosmok = false;
    Serial.println("connection failed");
    Serial.println();
    Serial.println("disconnecting.");
    cosm.stop();
  }
  */
  
         // read the response code. 200 means ok
        cosmResponse = cosm.parseInt();
        cosm.flush();
        cosm.stop();
        // give pvoutput some time to process the request
        delay(200);
    }
    else
    {
        cosmResponse=0;
    }
}


// This method calculates the number of digits in the
// sensor reading.  Since each digit of the ASCII decimal
// representation is a byte, the number of digits equals
// the number of bytes:

int getLength(int someValue) {
  // there's at least one byte:
  int digits = 1;
  // continually divide the value by ten,
  // adding one to the digit count for each
  // time you divide, until you're at 0:
  int dividend = someValue /10;
  while (dividend > 0) {
    dividend = dividend /10;
    digits++;
  }
  // return the number of digits:
  return digits;
}
