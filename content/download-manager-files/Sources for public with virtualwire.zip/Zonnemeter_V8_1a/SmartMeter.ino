 #define BUFSIZE 75

char buffer[BUFSIZE];
int bufpos = 0;
int Pos = 0;

#define StartChar = '/';
#define StopChar = '!';




boolean  readnextLine = false;

void ReadSmartMeter(){

  char c;

  while (Serial1.available()) { //if in while veranderd
     c = Serial1.peek();
  
    //  if (c == '/' ) //StartChar)    
    // we've loaded a line. Now parse the values
    if (read2Line()){
      Serial.print(buffer);
      long tl = 0;
      long tld =0;

      if (sendMeter) { 
          
        //Meter //1-0:1.8.1(00391.000*kWh)
          if (sscanf(buffer,"1-0:1.8.1(%ld.%ld%*s" , &tl, &tld) >0  )   
            { M1 = tl * 1000 + tld;}

          if (sscanf(buffer,"1-0:1.8.2(%ld.%ld%*s" , &tl, &tld) >0  )   
            { M2 = tl * 1000 + tld;}

          if (sscanf(buffer,"1-0:2.8.1(%ld.%ld%*s" , &tl, &tld) >0  )   
            { M3 = tl * 1000 + tld;}

          if (sscanf(buffer,"1-0:2.8.2(%ld.%ld%*s" , &tl, &tld) >0  )   
            { M4 = tl * 1000 + tld;}
      } //sendmeter



      if (readnextLine){

         if (sscanf(buffer,"(%ld.%ld%*s" , &tl, &tld) >0  ) {  
            GasMeter =  tl * 1000 + tld; // / 1000 ;  //niet meer delen door 1000 om een LONG te kunnen gebruiken ;) dus geen kuub maar liters
            readnextLine = false;
          }
      }

      //gas   0-1:24.3.0

       if (sscanf(buffer,"0-1:24.3.0(%6ld%4ld%*s" , &tl, &tld) > 0  ) {  //)
        GasReadDate=tl;
        GasReadTime=tld;
        readnextLine = true;
      }


  // Consumption

    if (sscanf(buffer,"1-0:1.7.0(%ld.%ld%*s" , &tl , &tld) >0  )   //)
      { Nactual = tl * 1000 + tld * 10;}

      // Supply       //       1-0:2.7.0(0000.00*kW)

    if (sscanf(buffer,"1-0:2.7.0(%ld.%ld%*s" , &tl , &tld) >0  )   //)
      { NactualReturn = tl * 1000 + tld * 10;}

      //we're done
      if (buffer[0] == '!' ) {
        GAS = GasMeter;
        CalculateSMValues();
        printData();
      }

    }
  }
} 


boolean read2Line() {

  char c;

  //  bufpos = 0;

  //  buffer[0] = '\0';
  c = Serial1.read();
  if (bufpos + 1 < BUFSIZE) {
    buffer[bufpos] = c; //c&127;
    bufpos++;
  }

  else
  { // return the partial line
    Serial.println(F("**Readline Buffer Full**"));

    buffer[bufpos] = '\0';
    bufpos = 0;
    return true;
  }

  if (c == '\n'){
    buffer[bufpos] = '\0';
    bufpos = 0;
    return true;
  }
  else return false;
}


void printData(){
        Serial.println("");
        Serial.print(F("Current Power : "));
        Serial.println(Nactual);
        Serial.print(F("Current NactualReturn : "));
        Serial.println(NactualReturn);
        Serial.print(F("GAS : "));
        Serial.println(GAS);
        Serial.print(F("Gas inleesdatum"));
        Serial.println(GasReadDate);
        Serial.print(F("Gas inleestijd"));
        Serial.println(GasReadTime);
        Serial.println("");
        Serial.println(F("*Meters*"));
        Serial.println(M1);
        Serial.println(M2);
        Serial.println(M3);
        Serial.println(M4);
}

void CalculateSMValues(){
  
   // calculate the actual Net consumption and Net delivery based on meterstanden  
   NtodayReturn=(M3+M4)-(M3tmp+M4tmp); //dag teruglevering (M3+M4) - (M3tmp+M4tmp)
   Ntoday=(M1+M2)-(M1tmp+M2tmp); //dag verbruik (M1+M2) - (M1tmp+M2tmp)
   
   NetToday = Ntoday - NtodayReturn; //net consumption from grid (import - export)
   TotalActual = S1.Actual + Nactual - NactualReturn; //Total actual energy concumption (Solar + Import - export)
   TotalToday = S1.Today + Ntoday - NtodayReturn; // Total energy consumption today (from solar and grid)
   
   // Calculate TotalActualAverage. Actual is read from meter every 10 seconds. To prevent registering a 10 sec usage of high power
   // calculate the average of 2 readings. use this in stats.
   TotalActualAverage = (TotalActual + TotalActualtmp) / 2;
   TotalActualtmp = TotalActual;
   
   if(TotalPeak < TotalActualAverage) TotalPeak = TotalActualAverage; //peak value actual consumption (reset each 5 minutes)
   if(Npeak < Nactual) Npeak = Nactual; // Peak value from grid(reset each 5 minutes)
   if(NpeakReturn < NactualReturn) NpeakReturn = NactualReturn; // peak value export (reset each 5 minutes)
   
  // GasUsage = (GAS - GAStmp)/1000; // calculate gas usage
   GasUsage = GAS - GAStmp;
   GasUsage = GasUsage / 1000;
   
   
   Serial.print("gasusage ");
   Serial.println(GasUsage,3);
   
   
   if(GasReadTime != GasReadTime_Prev && GasReadTime_Prev != -1){ //bij inlezen van nieuwe meterstand (en zeker weten dat er een begin stand is en niet -1).
       GasUsageLastHour = GAS - GasPrev;
       GasUsageLastHour = GasUsageLastHour / 1000;
       GasPrev = GAS;
       GasReadTime_Prev = GasReadTime;
       GasReadDate_Prev = GasReadDate;
       GasUpdateFlagPVout = 1;
       GasUpdateFlagCosm = 1;
   }
   if(GasReadTime_Prev == -1){ //at boot, don't upload gas usage in the first hour. first it has to register the current Gas value. this is downside of only gas value once an hour.
     GasReadTime_Prev = GasReadTime;
     GasPrev = GAS; 
     GasUpdateFlagPVout = 0;
     GasUpdateFlagCosm = 0;
     
   }
}
