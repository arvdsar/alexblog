//********* RF12 transceiver code *****
void Process_RF12(){
  
  if(millis() > (BlueLed_Milli + 500))  //Processing received data goes to fast to really show blue led. Now the led is reset to yellow after 500 millis in next cycle
    RGBLed(0,0,255);
    
   if (rf12_recvDone() && rf12_crc == 0){ // && rf12_len == sizeof inData_3) {
         nodeID = rf12_hdr & 0x1F;  // get node ID from header
        
        RGBLed(255,255,0); //Blue led at receiving data
        BlueLed_Milli = millis();
        procesInData(); //check which struct is being received, do the memcpy to struct and process data. then return.
        
      //  RGBLed(0,0,255); //yellow at idle
        // optional: rf12_recvDone(); // re-enable reception right away
    }

    if (sendTimer.poll(100))
  
   if(pendingOutput == 0); //if no data to be send, don't do anything and therefore skip next 'else if'  statements.
/*
    //send Payload 1 which is SolarMonitor data
  else if (pendingOutput  == SOLAR_STRUCT && rf12_canSend()) {  //pendingOutput is set in: getdatafromarray() and defines the structtype used
     //  Serial.println("RF12 sends Struct type 1");
       rf12_sendStart(0, &outData_1, sizeof outData_1); //0 is header. anders eens 2 proberen.
       // optional: rf12_sendWait(2); // wait for send to finish
       pendingOutput = 0;
    }
  
    //send Payload 2 which is Sun/Moon times data
    else if (pendingOutput == SUNTIMES_STRUCT && rf12_canSend()) {
//       Serial.println("RF12 sends Struct type 2");
       rf12_sendStart(0, &outData_2, sizeof outData_2); //0 is header. anders eens 2 proberen.
       // optional: rf12_sendWait(2); // wait for send to finish
       pendingOutput = 0;
    }
    */
    //just repeat else if statements above to add more structs (and add return type in getdatafromarray() function
}  
  
  
  // ****** end RF12 transceiver code *****
  
 void procesInData(){
     
  //Identify type of struct:
  byte WhichStruct = rf12_data[0]; //first byte in rf12 data (which is part of struct) identifies struct type
  
  Serial.println();
  Serial.print(F("RF12 data received, Struct: "));
  Serial.println(WhichStruct);
    
  switch (WhichStruct){
   //add more cases when you want to process more incoming data types
    
     case SOLAR_STRUCT:
        memcpy(&inData_1, (byte*) rf12_data, sizeof inData_1);
       
       //int's can be used directly in sendbuffer using %d. Floats need to be converted to char array strings.
       
        actual = inData_1.actual;
        peak = inData_1.peak;
        Nactual = inData_1.Nactual;
        NactualReturn = inData_1.NactualReturn;
        TotalActual = inData_1.TotalActual;
        today = inData_1.today;
        total = inData_1.total;
        ftoa(GasUsage,float(inData_1.GasUsage)/1000,3);   
        
        Serial.print("Domo status: ");
        Serial.println(inData_1.DomoStatus);
        Serial.println("_________________________");
        Serial.println();
        
        break; //end of solar struct case
   
    case  ALARM_STRUCT:
       memcpy(&inData_7, (byte*) rf12_data, sizeof inData_7);
      Serial.print("Alarm: ");
      Serial.println(inData_7.alarm);
      Serial.println();
      break;
   
    case TEMP_STRUCT: //Struct of sensor
      
      
      memcpy(&inData_3, (byte*) rf12_data, sizeof inData_3);
      Serial.print("Header nodeID: ");
      Serial.println(nodeID);
      Serial.print("which_Struct: ");
      Serial.println(inData_3.which_Struct);
      Serial.print("NodeID: ");
      Serial.println(inData_3.NodeID);
      Serial.print("Humidity: ");
      Serial.print(float(inData_3.humidity)/100);
      Serial.println("%");
      Serial.print("Temperature: ");
      Serial.print(float(inData_3.temp)/100);
      Serial.println("C");
      Serial.print("Light: ");
      Serial.println(inData_3.light);
      Serial.print("Voltage: ");
      Serial.print(float(inData_3.supplyV)/1000);
      Serial.println("V");
      Serial.print("Sendcounter: ");
      Serial.println(inData_3.sendcounter);
      Serial.println("_________________________");
      Serial.println();
      
    
      
      TempArr[nodeID-1] = inData_3.temp;
      if((nodeID-1) == 0 || (nodeID-1) == 1 || (nodeID-1) == 2) //only sensornode 1 and 2 have humidity sensor!
          HumidArr[nodeID-1] = inData_3.humidity;
      VoltArr[nodeID-1] = inData_3.supplyV;
      LightArr[nodeID-1] = inData_3.light; //because light remains an int, no need to store as char and convert with ftoa
      
      /* //for debugging uncomment. it will show the raw values stored in the array.
      Serial.println(F("Variables directly after storing in array in RFM12 processing"));
      Serial.println(F("Remember, they are al INT's to be devided by 100 or 1000, and -99/999 is for NOT Existing."));
      Serial.print("Temp: ");
      Serial.println(TempArr[nodeID-1]); 
       
      Serial.print("Humid: ");
      Serial.println(HumidArr[nodeID-1]);  
      
      Serial.print("Volt: ");
      Serial.println(VoltArr[nodeID-1]);
    
      Serial.print("Light: ");
      Serial.println(LightArr[nodeID-1]);  
      */    
      break;
    
    default:
      break;
  } //end switch
  
  
 }
 
 
