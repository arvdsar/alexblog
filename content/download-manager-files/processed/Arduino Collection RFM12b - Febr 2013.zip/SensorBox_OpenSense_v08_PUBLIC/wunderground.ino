void sendToWunderground(){
  //PushingBoxClient.stop();
  Serial.println(F("connecting to Wunderground.com..."));
    RGBLed(255,0,140); //mint green led at sending

EthernetClient WundergroundClient; //Wunderground client connection

   
        
  double DewPnt = dewPoint(double (TempArr[1])/100, double(HumidArr[1])/100); //DewPoint in Celcius
  DewPnt = 1.8 * DewPnt + 32; //create DewPnt in Fahrenheit
  
  if (WundergroundClient.connect("weatherstation.wunderground.com", 80) && (TempArr[1] != -999)) {
    Serial.println(F("connected to Wunderground and uploading"));

    WundergroundClient << F("GET /weatherstation/updateweatherstation.php?ID=");
    WundergroundClient << YOURID;
    WundergroundClient << F("&PASSWORD=");
    WundergroundClient << YOURPASSWORD;
    sprintf(webData, "&dateutc=%04d-%02d-%02d %02d:%02d:%02d", year(),month(),day(), hour(),minute(),second());
    WundergroundClient << webData;
    WundergroundClient << "&tempf=";    

      float fahrenheit = float(TempArr[1])/100;
     fahrenheit = 1.8 * fahrenheit + 32;

    ftoa(buffer,fahrenheit,1); //wunderground supports only 1 decimal
    WundergroundClient << buffer;
    WundergroundClient << "&humidity=";
    ftoa(buffer,float(HumidArr[1])/100,0);
    WundergroundClient << buffer;
    WundergroundClient << "&softwaretype=SensorBox_";
    WundergroundClient << VERSIONNR;
    WundergroundClient << "&dewptf=";
    WundergroundClient << DewPnt;
    WundergroundClient << "&action=updateraw";
    WundergroundClient << " HTTP/1.1" << endl;  //changed from 1.0
    WundergroundClient << "Host: weatherstation.wunderground.com" << endl;
    //WundergroundClient << "Connection: keep-alive" << endl;
    WundergroundClient << "Connection: close" << endl;

    WundergroundClient << "Accept: text/html" << endl;
    WundergroundClient << endl;
  
    Serial.println("Weather data send");
    
    delay(100); //give some time to send data
     while(WundergroundClient.available())
        {
            char c = WundergroundClient.read();
            Serial.print(c);
        }
        
    WundergroundClient.stop();
    Serial.println(F("Disconnected from Wunderground."));
    RGBLed(0,0,255); //Yellow Led at idle     

  }
  else {
    RGBLed(0,255,255); //Red led at connection error
    Serial.println(F("connection to Wunderground failed!"));
    byte err;
    pf.init(&err, 1, MACADDRESS); //reinit network interface
    Serial.println(F("Network reinitialized"));
    RGBLed(0,0,255); //Yellow Led at idle     

  }
}

double dewPoint(double celsius, double humidity)
{
	double A0= 373.15/(273.15 + celsius);
	double SUM = -7.90298 * (A0-1);
	SUM += 5.02808 * log10(A0);
	SUM += -1.3816e-7 * (pow(10, (11.344*(1-1/A0)))-1) ;
	SUM += 8.1328e-3 * (pow(10,(-3.49149*(A0-1)))-1) ;
	SUM += log10(1013.246);
	double VP = pow(10, SUM-3) * humidity;
	double T = log(VP/0.61078);   // temp var
	return (241.88 * T) / (17.558-T);
}
