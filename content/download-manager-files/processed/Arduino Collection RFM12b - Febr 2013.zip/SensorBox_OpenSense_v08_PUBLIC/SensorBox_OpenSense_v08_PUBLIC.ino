/*
Sensor Box based upon the sources of Open.Sen.Se and extended with additional code for receiving wireless sensors.
Written by Alexander van der Sar
http://www.vdsar.net 


v0.1 - prototype 
v0.2 - tried to make it generic for all sensors
v0.3 - revert 0.2. Make specific temperature sensor struct (remain with original idea) and optimze code
v0.4 - working with solar monitor values
v0.5 - added Domo received values. Bug found with using the array so duplicate values are uploaded. to be fixed
v0.6 - Rewritten to use arrays of INT's instead of 2D Char Arrays which were causing many headaches.
v0.6a - enlarged buffer[30] to 80. Size was to small for some texts.
v0.6b - enlarged buffer to 100 and changed Domo Light strings from letter to words
v0.6c - RGB led for status added
v0.6d - with sensor node 4 added
v0.7d - as v0.6d with upload to wunderground.com added (outdoor temp & humidity) Also added FlashMini.h for << in wunderground code
v0.7e - disabled daylight saving time and time offset. System running on UTC so time can be used to Wunderground.com directly
v0.7f - Calculated DewPoint added
v0.8 - same as v0.7f but needed version baseline


******************************************************************************************************************
PLEASE NOTE: TIME IS IN UTC. wunderground.com expects timestamp in UTC and not local time. Keep this in mind!
If you do need local time, convert it in the program or modify file 'time' and uncomment the daylight saving stuff. 
But in that case, do something to use correct time to wunderground.com
******************************************************************************************************************
*/

#define VERSIONNR "v0.8"
#define VERSION "V0.8 - Sensor Box to Open.Sen.Se & Wunderground.com - www.vdsar.net "


#include <SensuinoEth.h>
#include <SensuinoSerial.h>
#include <Ethernet.h>
#include <EthernetUdp.h>
#include <FlashMini.h>

#include <SPI.h>
#include <JeeLib.h>
#include <Time.h>
#include <HTTPClient.h>


#include "Userdefs.h"
#include <DataStructure.h> 

SensuinoEth pf;
EthernetUDP Udp;

char   webData[70];


const long int device_id = OpenSenseDeviceID; // This is your device's ID

unsigned long timeRef;
unsigned long BlueLed_Milli;
int lastMinute;


unsigned int actual=0;
unsigned int peak=0;
unsigned int Nactual=0;
unsigned int NactualReturn=0;
unsigned int TotalActual=0;
unsigned int today=0; 
unsigned long total=0;
char GasUsage[10]="0.0";

 Payload_1 inData_1; //Solarmonitor & Domotica Switches
 Payload_3 inData_3; //tempsensor data
 //Payload_4 inData_4; //float based sensor data
 Payload_7 inData_7;

MilliTimer sendTimer;  //related to RF12
byte pendingOutput=0; //related to RF12
int nodeID;    //node ID of tx, extracted from RF datapacket. Not transmitted as part of structure

int TempArr[10];
int HumidArr[10];
int VoltArr[20];
int LightArr[10]; 

int val = 0;
char buffer[100]; //was 30


char LampA_Status = ' ';
char LampB_Status = ' ';
char LampC_Status = ' ';
char LampD_Status = ' ';
char LampE_Status = ' ';
char LampF_Status = ' ';
char TuinVoor_Status = ' ';
char TuinMidden_Status = ' ';
char DeurLinks_Status = ' ';
char DeurRechts_Status = ' ';
char DeurAchter_Status = ' ';
char TuinAchter_Status = ' ';
long Prev_DomoStatus = 0;

int redPin = 13;
int greenPin = 12;
int bluePin = 11;

//************************* SETUP *********************


void setup() {
  Serial.begin(9600);  
  
  pinMode(4, OUTPUT);      // sets the digital pin as output 
  digitalWrite(4, HIGH);   // Disable SDCard on EthernetShield
 
  RGBLed(50,0,0); //White light at boot
  
  Serial.print(F("Starting "));
  Serial.println(VERSION);
  Serial.print(F("Data upload every "));
  Serial.print(updateOpenSenseInterval/1000);
  Serial.println(F(" seconds."));
  
  
   //initialize RFM12b transceiver. Before network init for compatibility reasons
  rf12_initialize(NODEID, FREQBAND, NETGROUP);  
  
    byte err;
  // Use the following if you don't want to use DHCP
  // pf.init(&err, 0, "aa:bb:cc:dd:ee:ff", "192.168.1.150", "192.168.1.1");// First IP is for the Arduino, second IP is for the gateway
  pf.init(&err, 1, MACADDRESS);

  delay(1000);
  
  pf.setSenseKey(OpenSenseAPIKEY);// This is your sense key
  
  Serial.println(F("LAN Init done"));

  // For each output feed, get the last value and trigger the right PIN on the arduino
  //We listen for incoming events on the device (uncomment when you want incoming events
  
  //pf.longPollSense(device_id);
  
  // Init timeRef
  timeRef = millis();
  
  //initialize array with -999 an never existing value.
  for(int x=0;x<10;x++)
     TempArr[x]=-999;
  for(int x=0;x<10;x++)
     HumidArr[x]=-999;
  for(int x=0;x<20;x++)
     VoltArr[x]=-999;
  for(int x=0;x<10;x++)
     LightArr[x]=-99;  //use -99 as non existing
     
  Serial.println(F("Total Init done"));
  
  RGBLed(0,255,0); //magenta light at start NTP request

  Udp.begin(8888);
  // wait until time is set
  Serial.println(F("UTC Set time using NTP")); //if you want local time, enable DST in file 'time' 
  while(!UpdateTime());
  Serial.println(F("UTC Time is set"));
    
  sprintf(webData, "Boottime: %02d-%02d-%04d %02d:%02d:%02d (UTC)", day(),month(),year(), hour(),minute(),second());
  Serial.println(webData);
   
  lastMinute = minute();

  RGBLed(0,0,255); //Yellow in Idle status
  
}// end setup

//*********************** LOOP **************************

void loop() {
  
      Process_RF12(); //continiously check for incomming RF12 data and send data when it is available

/* commented out because there is no need for the sensorbox to check for incomming events!
  byte _check = pf.longPollCheck();
    if(_check == 0) {
      pf.longPollSense(device_id);
      
      unsigned long int feed_id = pf.getLastFeedId();
      char *str = pf.getLastValue();
            
    } else if(_check == 2) {
      pf.longPollSense(device_id);
    }
  */
  
    // Send the values from input feeds every minute or so
    if (millis() - timeRef > updateOpenSenseInterval) {
      PostDataToSense(); //upload data to openSense, because of the many statements this is moved to seperate file
                         // it might be a good idea to split the uploading in multiple parts when it becomes very long.
      sendToWunderground(); 
      timeRef = millis();
    }
    
    /* if((lastMinute%5)==0)  //uncomment when you want to upload wunderground data only once per 5 minutes. (and comment sendToUnderground above )
        {
        Serial.println(F("Start uploading data to Wunderground"));
  
        sendToWunderground();
        lastMinute = minute();
        Serial.println(F("Finished uploading Data to Wunderground"));

        }*/
        
    delay(200);
}


//  ********   FTOA*******

char *ftoa(char *a, double f, int precision)
{
  long p[] = {0,10,100,1000,10000,100000,1000000,10000000,100000000};
  
  char *ret = a;
  long heiltal = (long)f;
  itoa(heiltal, a, 10);
  while (*a != '\0') a++;
  *a++ = '.';
  long desimal = abs((long)((f - heiltal) * p[precision]));
  itoa(desimal, a, 10);
  return ret;
}

void RGBLed(int red,int green, int blue){

 analogWrite(redPin,red);
 analogWrite(greenPin,green);
 analogWrite(bluePin,blue);
}


