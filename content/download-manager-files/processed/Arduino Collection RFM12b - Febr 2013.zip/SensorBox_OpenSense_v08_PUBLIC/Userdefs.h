// Local Network Settings
byte mac[] = { 0xD4, 0x28, 0xB2, 0xFE, 0xA0, 0xA1 }; // Must be unique on local network

#define OpenSenseAPIKEY "YOUR OPENSENSE API KEY"
#define OpenSenseDeviceID 9542
#define MACADDRESS "D4:28:B2;FE:A2;A3" //Change it to make it unique

long updateOpenSenseInterval = 60000;      // Time interval in milliseconds to update ThingSpeak

// WUNDERGROUND.COM CREDENTIALS:
#define YOURID "YOUR ID HERE"              // this is your wunderground station ID
#define YOURPASSWORD "YOURPASSWORD HERE"  //this is you wunderground password


//Define feed ID's of opensense: 
// create channels in open.sen.se and add them here. Node 1 = TempFeed1 and so on. You have to do some programming. See my webpage for more info http://www.vdsar.net
 #define TempFeed1 12345
 #define TempFeed2 12345
 #define TempFeed3 12345
 #define TempFeed4 12345
 
 #define HumidFeed1  12345
 #define HumidFeed2  12345
 #define HumidFeed3  12345
 #define HumidFeed4  12345
 
 #define VoltageFeed1 12345
 #define VoltageFeed2 12345
 #define VoltageFeed3 12345
 #define VoltageFeed4 12345
 
 #define LightFeed1 12345
 #define LightFeed2 12345
 #define LightFeed3 12345
 #define LightFeed4 12345

//energy monitor feed defines
 #define ActualFeed 12345
 #define PeakFeed 12345
 #define TodayFeed 12345
 #define TotalFeed 12345
 #define NactualFeed 12345
 #define NactualReturnFeed 12345
 #define TotalActualFeed 12345
 #define GasUsageFeed 12345
 
 #define IndoorLightingFeed 12345
 #define OutdoorLightingFeed 12345

/*
Sensor or Feeds:

Sensor 1: = Woonkamer / LCD Display
Sensor 2: = Outdoor 
Sensor 3: = Zolder 
Sensor 4: = Elin kamer


Feeds as defined on openSense:
   
You can copy and past the channels and feedID's from openSensSe easily. Put them here as reference.
You have to do some programming.




*/

//*********************************** DEFINE RF12 WIRELESS SETTINGS ******************
// ID 0 is reserved for OOK use
// node ID 31 is special because it will pick up packets for any node (in the same netGroup). 
#define NODEID    31
#define FREQBAND  RF12_868MHZ 
#define NETGROUP    201
#define ALT_NODEID   31 // alternative NODE ID included in Struct (not in header, that is NODEID). To be used when you send data to specific node, then this should contain origination node number
//Ter overdenking: nodeID 31 ontvangt alles. misschien houdt dit toestand wat bezig en kun je beter 29 kiezen en alleen broadcasts ontvangen. Al ontvang 31 alleen maar van NetGroup dus zou het niet uit moeten maken



