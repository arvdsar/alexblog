 void PostDataToSense(){
 
  Serial.println(F("Start uploading values to OpenSenSe."));
  RGBLed(255,0,255); //Green led at sending
      //  ftoa(tmpChar1,float(inData_3.temp)/100,2);
    //  ftoa(tmpChar2,float(inData_3.humidity)/100,2);
    //  ftoa(tmpChar3,float(inData_3.supplyV)/1000,2);
   
  // 3 x temp sensor updates    
      if(TempArr[0] != -999){
        ftoa(buffer,float(TempArr[0])/100,2);
        pf.postSense(TempFeed1, buffer);
        }
      
     if(TempArr[1] != -999){
        ftoa(buffer,float(TempArr[1])/100,2);
        pf.postSense(TempFeed2, buffer);
        }

     if(TempArr[2] != -999){
        ftoa(buffer,float(TempArr[2])/100,2);
        pf.postSense(TempFeed3, buffer);
        }
        
      if(TempArr[3] != -999){
        ftoa(buffer,float(TempArr[3])/100,2);
        pf.postSense(TempFeed4, buffer);
        }         
     
//  humiidity sensor updates
      
      if(HumidArr[0] != -999){
        ftoa(buffer,float(HumidArr[0])/100,2);
        pf.postSense(HumidFeed1, buffer);
        }
      
      if(HumidArr[1] != -999){
        ftoa(buffer,float(HumidArr[1])/100,2);
        pf.postSense(HumidFeed2, buffer);
        }
     
      if(HumidArr[2] != -999){
        ftoa(buffer,float(HumidArr[2])/100,2);
        pf.postSense(HumidFeed3, buffer);
        }    
      
 //many sensor supply voltage updates
       
      if(VoltArr[0] != -999){
        ftoa(buffer,float(VoltArr[0])/1000,2);
        pf.postSense(VoltageFeed1, buffer);
        }
      
      if(VoltArr[1] != -999){
        ftoa(buffer,float(VoltArr[1])/1000,2);
        pf.postSense(VoltageFeed2, buffer);
        }

      if(VoltArr[2] != -999){
        ftoa(buffer,float(VoltArr[2])/1000,2);
        pf.postSense(VoltageFeed3, buffer);
        }
      if(VoltArr[3] != -999){
        ftoa(buffer,float(VoltArr[3])/1000,2);
        pf.postSense(VoltageFeed4, buffer);
        }

      
  
  //  Light sensor updates    
      if(LightArr[0] != -99){
      sprintf(buffer,"%s", LightArr[0]);
      pf.postSense(LightFeed1, buffer);
      }
 
      if(LightArr[1] != -99){
      sprintf(buffer,"%s", LightArr[1]);
      pf.postSense(LightFeed2, buffer);
      } 
      
      if(LightArr[2] != -99){
      sprintf(buffer,"%s", LightArr[2]);
      pf.postSense(LightFeed3, buffer);
      }  



//Energy Monitor values
      sprintf(buffer,"%d", actual);
      pf.postSense(ActualFeed, buffer);
      sprintf(buffer,"%d", peak);
      pf.postSense(PeakFeed, buffer);
      sprintf(buffer,"%d", today);
      pf.postSense(TodayFeed, buffer);
      sprintf(buffer,"%d", total);
      pf.postSense(TotalFeed, buffer);
      sprintf(buffer,"%d", Nactual);
      pf.postSense(NactualFeed, buffer);
      sprintf(buffer,"%d", NactualReturn);
      pf.postSense(NactualReturnFeed, buffer);
      sprintf(buffer,"%d", TotalActual);
      pf.postSense(TotalActualFeed, buffer);
      sprintf(buffer,"%s", GasUsage);
      pf.postSense(GasUsageFeed, buffer);
      
  // Domotica Light status

if (inData_1.DomoStatus != Prev_DomoStatus){

  ProcessReceivedDomo(inData_1.DomoStatus); // extract switch statusses from Domo received value
  
  
   //indoorlighting:
   
   strcpy(buffer,"Lights on: ");
   if(LampA_Status == 'A')
     strcat(buffer,"LampA ");
   if(LampB_Status == 'B')
     strcat(buffer,"LampB ");
   if(LampC_Status == 'C') 
     strcat(buffer,"LampC ");
   if(LampD_Status == 'D')
     strcat(buffer,"LampD ");
   if(LampE_Status == 'E')
     strcat(buffer,"LampE ");
   if(LampF_Status == 'F')
     strcat(buffer,"LampF ");
   
   pf.postSense(IndoorLightingFeed, buffer);
   
   strcpy(buffer,"Lights on: ");
   if(TuinVoor_Status == 'V')
     strcat(buffer,"TuinVoor ");
   if(TuinMidden_Status == 'M')
     strcat(buffer,"TuinMidden ");
   if(TuinAchter_Status == 'S') 
     strcat(buffer,"TuinAchter ");
   if(DeurLinks_Status == 'L')
     strcat(buffer,"DeurLinks ");
   if(DeurRechts_Status == 'R')
     strcat(buffer,"DeurRechts ");
   if(DeurAchter_Status == 'A')
     strcat(buffer,"DeurAchter");
   
   pf.postSense(OutdoorLightingFeed, buffer);
    
}
      
 Serial.println(F("Finished uploading values to OpenSenSe."));  
 RGBLed(0,0,255); //Yellow Led at idle     
 } //end of PostDataToSense();
 

