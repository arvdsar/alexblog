void Alarms(){
  
  
  //the alarms below are to inform using prowl! (www.prowlapp.com) that the maximum power is in use. In NL we are limited to sometimes 25 or 35 Amps current
  //if we exceed this current the main fuse in our house will go off. calculatie: Power = volts & current (6000 = 240volts & 25 Amps)
  
 if(TotalPeak >= 7900 && TotalPeak < 8350 && Notified_A == 0){ // Max 1 alarm per uur (tussen 5500 - 5950 watt)
    Avviso.push("HOOG ENERGIE VERBRUIK", "Hoog vermogen > 7900W uit net!", 1); //(prio 1 = high) (Translation: High energy Usage, High Power > 5550 watts from grid)
    Notified_A=1;  
    }
  
  if(TotalPeak >= 8350 && Notified_B == 0){ // max 1 alarm per 5 minutes bij 8350 watt
    Avviso.push("MAX ENERGIE VERBRUIK OVERSCHREDEN", "Meer dan 8350W consumptie uit net! Let op hoofdzekering!", 2); //prio 2 is emergency meaning Alarm will sound also in quiet hours on prowlapp
    // Translation of above: " Maxumum power usage exceeded", " more than 6000w consumption from grid. Watch the main fuse!.
    Notified_B=1;
  }
  
}
