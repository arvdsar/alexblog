//*****************************************************************
//*                                                                
//*  userdefines                                                   
//*****************************************************************
#ifndef userdefs_h
#define userdefs_h

#define PROWLAPI_KEY "YOUR PROWLAPI KEY HERE" //www.prowlapp.com
#define PVOUTPUT_KEY "YOUR PVOUTPUT API KEY HERE" //www.pvoutput.org


#define NACTUAL_HIGH       10000  //Used to determine if value from smart meter is valid. values below this watts are valid
#define NACTUALRETURN_HIGH  4000   //same for PV power to grid

float kWhCosts = 0.21; //price of a kwh 
float GasCosts = 0.56; //price of a m3 of Gas

// Every output has it's own system ID. Set to 0 if not used
static int SID1 = YOUR PVOUTPUT SYSTEM ID (like 12345); 
//static int SID2 = 0;
//static int SID3 = 0;

// Network variables - Change them to suit your network!
static byte mac[] = { 0xAE, 0xBD, 0xBE, 0xEF, 0xFC, 0xFF }; // MAC address
static byte ip[] = { 192, 168, 1, 25 }; // IP of arduino
static byte gateway[] = { 192, 168, 1, 1 };
static byte subnet[] = { 255, 255, 255, 0 };
static byte dnsserver[] = { 192, 168, 1, 1 };

static byte DomoticaBoxIP[] = { 192, 168, 1, 26 }; //IP Addres of DomoticaBox
static int DomoticaBoxPort = 23;  //port on which the domoticabox listens

#endif
