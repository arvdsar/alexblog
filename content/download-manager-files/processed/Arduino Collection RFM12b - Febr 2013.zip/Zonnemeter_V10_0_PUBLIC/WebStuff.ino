const int maxLength = 25;
String inString = String("");
// storage for last page access


void ServeWebClients() 
{
    EthernetClient client = server.available();
    int i;
    if (client) 
    {
      inString = client.readStringUntil('\n');
      client << F("HTTP/1.1 200 OK") << endl;
      client << F("Content-Type: application/x-javascript") << endl << endl;
      i=inString.indexOf("?");
      if(i!=-1) readValue(inString,i);
      showStatus(client);
      client.stop();
    }
}

void readValue(String input,int i)
{
    long val=0;
    bool neg=false;
    int j=i+3;
    int address = input[i+1]-'0';
    if(address>=0 && address<15)
    {
        char c=input[j];
        if(c=='-')
        {
           neg=true;
           j++;
           c=input[j];
        }
        while(c>='0' && c<='14')
        {
           val = 10*val + (c-'0');
           j++;
           c=input[j];
        }
        if(neg) val=-val;
        writelong(address,val);
    }
}

void showStatus(EthernetClient client)
{
    int i;
    client << DateTime(now()) << endl;
    client << F(VERSION) << endl;

    solarStatus(client, S1);
  //  solarStatus(client, S2);
  //  solarStatus(client, S3);
   
        float NactualCosts =float(Nactual) / 1000; //)*kWhCosts;
        NactualCosts = NactualCosts * kWhCosts;
        
        float NtodayCosts = float(Ntoday) / 1000;
        NtodayCosts = NtodayCosts * kWhCosts;
        
        float NactualReturnCosts = float(NactualReturn) / 1000;
        NactualReturnCosts = NactualReturnCosts * kWhCosts;
        
        float NtodayReturnCosts = float(NtodayReturn) / 1000;
        NtodayReturnCosts = NtodayReturnCosts * kWhCosts;
        
        float TotalTodayCosts = float(TotalToday) / 1000;
        TotalTodayCosts = TotalTodayCosts * kWhCosts;
        
        float TotalPeakCosts = float(TotalPeak) / 1000;
        TotalPeakCosts = TotalPeakCosts * kWhCosts;

        float NetTodayCosts = float(NetToday) / 1000;
        NetTodayCosts = NetTodayCosts * kWhCosts;    
    
    
        float TotalActualCosts = float(TotalActual) / 1000;
        TotalActualCosts = TotalActualCosts * kWhCosts;
        
        client << F("LichtNet Actual Import:") << Nactual << " W" << "            EUR: " << NactualCosts << endl; //grid actual import
        client << F("LichtNet Today Import:") << Ntoday << " Wh" << "            EUR: " << NtodayCosts << endl; //grid import today
        client << F("LichtNet Peak Import: ") << Npeak << " W" << endl << endl; //grid peak import (max actual value in 5 minutes)
        
        client << F("Teruglevering Actual: ") << NactualReturn << " W" << "            EUR: " << NactualReturnCosts << endl; // export actual
        client << F("Teruglevering Today: ") << NtodayReturn << " Wh" << "            EUR: " << NtodayReturnCosts <<endl; //export toay
        client << F("Teruglevering Peak: ") << NpeakReturn << " W" << endl << endl; // export peak
        
        client << F("Energie verbruik Today (Grid+Sun): ") << TotalToday << " Wh" << "            EUR: " << TotalTodayCosts << endl; //energy consumption today
        client << F("Netto Import LichtNet (Import - Export) today: ") << NetToday << "            EUR: " << NetTodayCosts << endl << endl; //net import from gid today
        
        client << F("Energie verbruik Peak: ") <<TotalPeak << "            EUR: " << TotalPeakCosts <<endl; //energy consumption peak
        client << F("Energie verbruik Actual: ") << TotalActual << "            EUR: " << TotalActualCosts <<endl; //energy consumption actual
        client << F("Energie verbruik Gem. Actual: ") << TotalActualAverage << endl; //energy consumption average actual (two actual readings)

        client << F("Gasverbruik Today: ") << GasUsage << "            EUR: " << float(GasUsage*GasCosts) <<endl; //gas usage today
        client << F("Gasverbruik last hour: ") << GasUsageLastHour << endl; //gas usage during last hour
        client << F("Inleestijd Gasverbruik: ") << GasReadTime << endl << endl; //timestamp of reading gas value from smart meter
    
    
    client << F("Eeprom:") << endl;  
    for(i=0;i<10;i++)
    {
      client << i << " : " << readlong(i) << endl;
    }

   client << F("PvOutput response: ") << pvResponse << endl;


}


void UpdateLCD(){
  
  Serial.print(F("UpdateLCD function called: "));
  EthernetClient DomoticaClient;          // client to connect to Domotica Box

 if(!DomoticaClient.connected()){
  // Serial.println("Domoticabox not yet connected!");
   if(DomoticaClient.connect(DomoticaBoxIP, DomoticaBoxPort))
    // Serial.println("connecting...");
     if(DomoticaClient.connected()){
      // Serial.println("DomoticaBox is CONNECTED ;-)");
       showStatusLCD(DomoticaClient, S1); 
     }
  /*   else 
       Serial.println("DomoticaBox cannot connect");
    */ 
 }
     else {
      // Serial.println("DomoticaBox still connected");
       showStatusLCD(DomoticaClient,S1);
     }
 
 DomoticaClient.stop(); //disconnect DomoticaBox. Seems that each time new connection is created.
}



void showStatusLCD(EthernetClient DomoticaClient, Solar S) //Send string to domoticabox for LCD display
{  
   if(S.SID>0) 
  {  
  //since version v9.1e the domotica gateway is modified to use RFM12b transmiter with RF12 library. Now 66 bytes can be transfered
  //in one transaction. Also it uses a struct which means we can send data more efficient. 
  //logic to use struct is in domotica gateway. This solar monitor application sends all data at once and domotica gateway will
  //do the rest.
  DomoticaClient.print("TX868=V1,"); //Solar Actual
  DomoticaClient.print(S.Actual);
  DomoticaClient.print(",");
  DomoticaClient.print(S.Today); //Solar Today
  DomoticaClient.print(",");
  DomoticaClient.print(S.Peak);
  DomoticaClient.print(","); // Solar Total
  DomoticaClient.print(S.Total/1000);
  DomoticaClient.print(",");
  DomoticaClient.print(TotalActual);
  DomoticaClient.print(","); //Net export actual
  DomoticaClient.print(Nactual);
  DomoticaClient.print(",");
  DomoticaClient.print(NactualReturn);
  DomoticaClient.print(",");
  DomoticaClient.print(GasUsage);
  DomoticaClient.print(",");
  DomoticaClient.print(NetToday);
  DomoticaClient.print(","); //Net export actual 
  delay(500); //Idle time to give some slack to process data (maybe it can be removed)
  }
}


void solarStatus(EthernetClient client, Solar S)
{
    if(S.SID>0)
    {
      
        float ActualCosts = float(S.Actual) / 1000;
        ActualCosts = ActualCosts * kWhCosts;
        
        float TodayCosts = float(S.Today) / 1000;
        TodayCosts = TodayCosts * kWhCosts;
       
        float TotalCosts = float(S.Total) / 1000;
        TotalCosts = TotalCosts * kWhCosts;
        
      
        client << S.SID << endl;
        client << F("Solar Actual: ") << S.Actual << F("            EUR: ") << ActualCosts << endl;
        client << F("Solar Today: ") << S.Today << F("            EUR: ") << TodayCosts << endl;
        client << F("Solar Total: ") << S.Total << F("            EUR: ") << TotalCosts << endl; 
        client << F("Solar Peak: ") << S.Peak << endl << endl;
    }
}

char* DateTime(time_t t)
{
    int y = year(t)-2000;
    if(y < 0) sprintf(webData,"Invalid");
    else      sprintf(webData, "%02d.%02d.%02d %02d:%02d:%02d", day(t),month(t),y,hour(t),minute(t),second(t));
    return webData;
}
