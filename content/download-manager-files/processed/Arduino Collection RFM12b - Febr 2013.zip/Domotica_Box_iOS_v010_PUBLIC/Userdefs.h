//Create scenario's at pushingBox.com and add the scenario key here. Scenario's are samples as I used.

char PushingBox_DEVID1[] = "YOUR SCENARIOKEY1 HERE"; //Scenario : "Someone at the door"
char PushingBox_DEVID2[] = "YOUR SCENARIOKEY 2 HERE"; //Scenario : "Domotica Gateway Started
char PushingBox_DEVID3[] = "YOUR SCENARIOKEY 3 HERE"; //Scenario : "IPCam voordeur ON"

char PushingBoxServer[] = "api.pushingbox.com";


//********* Arduino Manager iOS *******
int iOS_Port = 23400; //the port you want to use to connect with Arduino Manager app (config in iOS App too)
int MyServer_Port = 23;



 // the media access control (ethernet hardware) address for the shield:
byte mac[] = { 0xDE, 0xAE, 0xAE, 0xEF, 0x4E, 0x2D }; // Change it a little bit to make it unique ;-)
//the IP address for the shield:
byte ip[] = { 192, 168, 1, 26 };   //the IP adres of this device. 
// the router's gateway address:
byte gateway[] = { 192, 168, 1, 1 };
// the subnet:
byte subnet[] = { 255, 255, 255, 0 };
byte dnsserver[] = { 208, 67, 222, 222 };


//*********************************** DEFINE RF12 WIRELESS SETTINGS ******************
// ID 0 is reserved for OOK use
// node ID 31 is special because it will pick up packets for any node (in the same netGroup). 
#define NODEID    30
#define FREQBAND  RF12_868MHZ 
#define NETGROUP    201
#define ALT_NODEID   30 // alternative NODE ID included in Struct (not in header, that is NODEID). To be used when you send data to specific node, then this should contain origination node number

