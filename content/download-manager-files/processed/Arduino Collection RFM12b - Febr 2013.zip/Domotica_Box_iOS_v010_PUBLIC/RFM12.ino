//********* RF12 transceiver code *****
void Process_RF12(){
   if (rf12_recvDone() && rf12_crc == 0){ // && rf12_len == sizeof inData_3) {
      nodeID = rf12_hdr & 0x1F;  // get node ID from header
      procesInData(); //check which struct is being received, do the memcpy to struct and process data. then return.
        // optional: rf12_recvDone(); // re-enable reception right away
    }

    if (sendTimer.poll(100))
  
   if((PendingOutputSolar == 0) && (PendingOutputSun == 0) && (PendingOutputTime == 0)); //if no data to be send, don't do anything and therefore skip next 'else if'  statements.

      //send Payload 2 which is Sun/Moon times data
    else if (PendingOutputSun == SUNTIMES_STRUCT && rf12_canSend()) {
       Serial.println("RF12 sends Struct type 2");
       rf12_sendStart(0, &outData_2, sizeof outData_2); //0 is header. 
       // optional: rf12_sendWait(2); // wait for send to finish
       PendingOutputSun = 0;

    }
    
        //send Payload 1 which is SolarMonitor data
  else if (PendingOutputTime  == TIME_STRUCT && rf12_canSend()) {  //pendingOutput is set in: getdatafromarray() and defines the structtype used
       Serial.println("RF12 sends Struct type 8");
       rf12_sendStart(0, &outData_8, sizeof outData_8); //0 is header.
       // optional: rf12_sendWait(2); // wait for send to finish
             PendingOutputTime = 0;
    }
  
    //send Payload 1 which is SolarMonitor data
  else if (PendingOutputSolar  == SOLAR_STRUCT && rf12_canSend()) {  //pendingOutput is set in: getdatafromarray() and defines the structtype used
       Serial.println("RF12 sends Struct type 1");
       rf12_sendStart(0, &outData_1, sizeof outData_1); //0 is header.
       // optional: rf12_sendWait(2); // wait for send to finish
             PendingOutputSolar = 0;
    }
  

    
    //just repeat else if statements above to add more structs (and add return type in getdatafromarray() function
}  
  
  
  // ****** end RF12 transceiver code *****
  
 void procesInData(){
   
  Serial.print("RF12 data ontvangen ");
  
  //Identify type of struct:
  byte WhichStruct = rf12_data[0]; //first byte in rf12 data (which is part of struct) identifies struct type
  
  switch (WhichStruct){
   //add more cases when you want to process more incoming data types
    
    case TEMP_STRUCT: //Struct of sensor type for Temperature. 
      Serial.println("Received StructType = 3 - tempsensor data");
      memcpy(&inData_3, (byte*) rf12_data, sizeof inData_3);
      
      if(nodeID == 2){ //nodeID2 is the outdoor temperature sensor
        outdoorTemp = float(inData_3.temp)/100;
      }
      if(nodeID == 1){ //nodeID1 is the indoor temperature sensor 
        indoorTemp = float(inData_3.temp)/100;
      }

      Serial.print("which_Struct: ");
      Serial.println(inData_3.which_Struct);
      Serial.print("NodeID: ");
      Serial.println(inData_3.NodeID);
      Serial.print("Humidity: ");
      Serial.print(float(inData_3.humidity/100));
      Serial.println("%");
      Serial.print("Temperature: ");
      Serial.print(float(inData_3.temp)/100);
      Serial.println("C");
      Serial.print("Voltage: ");
      Serial.print(float(inData_3.supplyV)/1000);
      Serial.println("V");
      Serial.print("Sendcounter: ");
      Serial.println(inData_3.sendcounter);
      Serial.println("________________________");

      
      break;
    
    default:
      break;
  } //end switch
  
  
 }
 
 
