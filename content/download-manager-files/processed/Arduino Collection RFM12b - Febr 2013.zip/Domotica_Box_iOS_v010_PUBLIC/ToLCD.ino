/*
This file contains the function to periodically update the Remote connected LCD display via 868Mhz.
The outData_1 stuct contains a LONG value for switch status. it is transfered each time to 
the LCD display together with other solar monitor data
*/

byte sendSwitchStatus(){
  
  
  outData_1.DomoStatus = 0x0000; // 00000000.00000000 (16 bits)
  
  if(LampA_Status == 1)
    outData_1.DomoStatus = outData_1.DomoStatus | 0x8000; // 1000.0000.0000.0000 
  if(LampB_Status == 1)
    outData_1.DomoStatus = outData_1.DomoStatus | 0x4000; // 0100.0000.0000.0000
  if(LampC_Status == 1)
    outData_1.DomoStatus = outData_1.DomoStatus | 0x2000; // 0010.0000.0000.0000
  if(LampD_Status == 1)
    outData_1.DomoStatus = outData_1.DomoStatus | 0x1000; // 0001.0000.0000.0000
  if(LampE_Status == 1)
    outData_1.DomoStatus = outData_1.DomoStatus | 0x0800; // 0000.1000.0000.0000
  if(LampF_Status == 1)
    outData_1.DomoStatus = outData_1.DomoStatus | 0x0400; // 0000.0100.0000.0000
  if(digitalRead(RELAY1) == 0) 
    outData_1.DomoStatus = outData_1.DomoStatus | 0x0200; // 0000.0010.0000.0000   Tuinvoor
  if(digitalRead(RELAY2) == 0)
    outData_1.DomoStatus = outData_1.DomoStatus | 0x0100; // 0000.0001.0000.0000   TuinMidden
  if(digitalRead(RELAY4) == 0)
    outData_1.DomoStatus = outData_1.DomoStatus | 0x0080; // 0000.0000.1000.0000   Deurlinks
  if(digitalRead(RELAY3) == 0)
    outData_1.DomoStatus = outData_1.DomoStatus | 0x0040; // 0000.0000.0100.0000   Deurrechts
  if(DeurAchter_Status == 1)
    outData_1.DomoStatus = outData_1.DomoStatus | 0x0020; // 0000.0000.0010.0000    
  if(TuinAchter_Status == 1)
    outData_1.DomoStatus = outData_1.DomoStatus | 0x0010; // 0000.0000.0001.0000    
  
    PendingOutputSolar = SOLAR_STRUCT;

  return(SOLAR_STRUCT); //set pending output on 1 so that RF12_Process will process the data
        
  //****** NO NEED TO START RF12 FUNCTION HERE. IT IS STARTED IN MAIN() LOOP  CONTINIOUSLY ******
        
 
 
}
