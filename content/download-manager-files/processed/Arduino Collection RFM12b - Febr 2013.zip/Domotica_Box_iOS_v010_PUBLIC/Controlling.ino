// This file contains the statements to switch relays, read data or send wireless transmissions based on 'readString'

void StartSwitching(String readString){
  
  
 
  
        RemoteReceiver::disable(); //disable the 434mhz receiver of the remote switch library to prevent receiving date send by the arduino itself
      
       if (readString.startsWith("TX868")){
          Serial.println(F("TX868 RF12 send request detected"));
          
          StringParse(readString); //parse received readstring and copy values to struct for sending (RF12) and iOS
          Serial.print(F("TX868 results in PendingOutputSolar = "));
          Serial.println(PendingOutputSolar);
          Serial.print(F("TX868 results in PendingOutputSun = "));
          Serial.println(PendingOutputSun);
          // pendingOutput is set in Stringparse as a return of GetDataFromArray().           
          }
      

                
     else if(readString.startsWith("tuin")){  // optimize IF statements. Starts with "tuin"  then ... otherwise Lamp, etc. 
          if(readString == "tuinvoor_ON"){
            digitalWrite(RELAY1, false);
            iosController.writeMessage("TuinVoor",!digitalRead(RELAY1));
            }
          else if (readString == "tuinvoor_OFF"){
            digitalWrite(RELAY1, true);
            iosController.writeMessage("TuinVoor",!digitalRead(RELAY1));
          }
          else if (readString == "tuinmidden_ON"){
            digitalWrite(RELAY2, false);
            iosController.writeMessage("TuinMidden",!digitalRead(RELAY2));
            }
          else if (readString == "tuinmidden_OFF"){
            digitalWrite(RELAY2, true);
            iosController.writeMessage("TuinMidden",!digitalRead(RELAY2));
            }
          else if (readString == "tuinachter_ON"){
            elroTransmitter.sendSignal(1,'E',true);
            TuinAchter_Status=1;
            iosController.writeMessage("TuinAchter",TuinAchter_Status);
            }
           else if (readString == "tuinachter_OFF"){
             elroTransmitter.sendSignal(1,'E',false);
             TuinAchter_Status=0;
             iosController.writeMessage("TuinAchter",TuinAchter_Status);
            }        
        } //end if TUIN
        
        
        else if(readString.startsWith("deur")){  //optimize flow 'deur' 
        
           if (readString == "deurlinks_ON"){
            digitalWrite(RELAY4, false);
            iosController.writeMessage("DeurLinks",!digitalRead(RELAY4));
            }
          else if (readString == "deurlinks_OFF"){
            digitalWrite(RELAY4, true);
            iosController.writeMessage("DeurLinks",!digitalRead(RELAY4));
            }
          else if (readString == "deurrechts_ON"){
            digitalWrite(RELAY3, false);
            iosController.writeMessage("DeurRechts",!digitalRead(RELAY3));
            }
          else if (readString == "deurrechts_OFF"){
            digitalWrite(RELAY3, true);
            iosController.writeMessage("DeurRechts",!digitalRead(RELAY3));
            }
          else if (readString == "deurachter_ON"){
            elroTransmitter.sendSignal(1,'D',true);
            DeurAchter_Status=1;
            iosController.writeMessage("DeurAchter",DeurAchter_Status);
          }    
        
        else if (readString == "deurachter_OFF"){
          elroTransmitter.sendSignal(1,'D',false);
          DeurAchter_Status=0;
          iosController.writeMessage("DeurAchter",DeurAchter_Status);
          }  
        } //end if optimize for 'deur
        
        
        
        
       else if(readString.startsWith("lamp")){ //optimize IF 
        
          if (readString == "lampA_ON"){
            actionTransmitter.sendSignal(1,'A',true);
            LampA_Status=1;
            iosController.writeMessage("LampA",LampA_Status);
          }
        
          else if (readString == "lampA_OFF"){
            actionTransmitter.sendSignal(1,'A',false);
            LampA_Status=0;
            iosController.writeMessage("LampA",LampA_Status);
          }
        
          else if (readString == "lampB_ON"){
            actionTransmitter.sendSignal(1,'B',true);
            LampB_Status=1;
            iosController.writeMessage("LampB",LampB_Status);
          }
        
          else if (readString == "lampB_OFF"){
            actionTransmitter.sendSignal(1,'B',false);
            LampB_Status=0;
            iosController.writeMessage("LampB",LampB_Status);
          }
        
          else if (readString == "lampC_ON"){
            actionTransmitter.sendSignal(1,'C',true);
            LampC_Status=1;
            iosController.writeMessage("LampC",LampC_Status);
          }
        
          else if (readString == "lampC_OFF"){
            actionTransmitter.sendSignal(1,'C',false);
            LampC_Status=0;
            iosController.writeMessage("LampC",LampC_Status);
          }
        
          else if (readString == "lampD_ON"){
            actionTransmitter.sendSignal(1,'D',true);
            LampD_Status=1;
            iosController.writeMessage("LampD",LampD_Status);
          }
        
          else if (readString == "lampD_OFF"){
            actionTransmitter.sendSignal(1,'D',false);
            LampD_Status=0;
            iosController.writeMessage("LampD",LampD_Status);
          }
        
          else if (readString == "lampE_ON"){
            actionTransmitter.sendSignal(1,'E',true);
            LampE_Status=1;
            iosController.writeMessage("LampE",LampE_Status);
          }
        
          else if (readString == "lampE_OFF"){
            actionTransmitter.sendSignal(1,'E',false);
            LampE_Status=0;
            iosController.writeMessage("LampE",LampE_Status);
          }
          else if (readString == "lampF_ON"){
            actionTransmitter.sendSignal(2,'D',true);
            LampF_Status=1;
            iosController.writeMessage("LampF",LampF_Status);
          }
        
          else if (readString == "lampF_OFF"){
            actionTransmitter.sendSignal(2,'D',false);
            LampF_Status=0;
            iosController.writeMessage("LampF",LampF_Status);
          }
        } //end optimize if 'lamp' 
        
        else if (readString == "IPCam1_ON"){ // switch for IP Camera 1
          actionTransmitter.sendSignal(2,'C',true);
          IPCam1_Status=1;
          iosController.writeMessage("IPCam1",IPCam1_Status);
          sendToPushingBox(PushingBox_DEVID3); //Send ProwlApp alert that IPCam goes ON

         }
        else if (readString == "IPCam1_OFF"){
          actionTransmitter.sendSignal(2,'C',false);
          IPCam1_Status=0;
          iosController.writeMessage("IPCam1",IPCam1_Status);
          sendToPushingBox(PushingBox_DEVID3); //Send ProwlApp alert that IPCam goes OFF

         }
        
        else if (readString == "Vertrekken"){
          MsTimer2::stop(); //Mstimer2 stop. Otherwise DelayedBedtijd() would be called every 60 sec.     
          iosController.writeMessage("NaarBed",0);
          
          
        
          actionTransmitter.sendSignal(1,'E',false);
          LampE_Status=0;
          iosController.writeMessage("LampE",LampE_Status);
          
          actionTransmitter.sendSignal(1,'D',false);
          LampD_Status=0;
          iosController.writeMessage("LampD",LampD_Status);
          
          actionTransmitter.sendSignal(1,'C',false);
          LampC_Status=0;
          iosController.writeMessage("LampC",LampC_Status);
          
          actionTransmitter.sendSignal(1,'B',false);
          LampB_Status=0;
          iosController.writeMessage("LampB",LampB_Status);
          
          actionTransmitter.sendSignal(1,'A',false);
          LampA_Status=0;          
          iosController.writeMessage("LampA",LampA_Status);
        }
        
        else if (readString == "Opstaan"){
          MsTimer2::stop(); //Mstimer2 stop. Otherwise DelayedBedtijd() would be called every 60 sec.     
          iosController.writeMessage("NaarBed",0);
         
         // Uncomment to also turn LampE on. 
        //  actionTransmitter.sendSignal(1,'E',true);
        //  LampE_Status=1;
        //  iosController.writeMessage("LampE",LampE_Status);
          
          actionTransmitter.sendSignal(1,'D',true);
          LampD_Status=1;
          iosController.writeMessage("LampD",LampD_Status);
          
          actionTransmitter.sendSignal(1,'C',true);
          LampC_Status=1;
          iosController.writeMessage("LampC",LampC_Status);
          
          actionTransmitter.sendSignal(1,'B',true);
          LampB_Status=1;
          iosController.writeMessage("LampB",LampB_Status);
          
          actionTransmitter.sendSignal(1,'A',true);
          LampA_Status=1;          
          iosController.writeMessage("LampA",LampA_Status);
        } 
        
        else if(readString == "Bedtijd"){
          iosController.writeMessage("NaarBed",1);
          MsTimer2::set(60000, DelayedBedtijd); // 60.000ms period
          MsTimer2::start(); 
          //
        }

       sendSwitchStatus(); //update switch status and update Struct with this info. if this works, below commented part can be removed. 
       /*
        if(no_SendSwitchStatus == 0){ //if it's 1 then an update of switch status is not necessary
           delay(200); //maybe this helps ;-)
           sendSwitchStatus(); //Send the switch status each time a command has been received
          }
         else
           no_SendSwitchStatus = 0; //reset it back to zero
        */
     RemoteReceiver::enable(); //reenable the 434mhz receiver (of the remote switch library) again.
  
//Don't put serial.print debug lines in this function. Don't ask why, but it crashes in that case!
}


void DelayedBedtijd(){  // delayed activation of 'Bedtijd'
       
        RemoteReceiver::disable();//disable the remote receiver
        
        MsTimer2::stop(); //Mstimer2 stop. Otherwise DelayedBedtijd() would be called every 60 sec.     
        iosController.writeMessage("NaarBed",0);
       

          
          actionTransmitter.sendSignal(1,'E',false);
          LampE_Status=0;
          iosController.writeMessage("LampE",LampE_Status);
          
          actionTransmitter.sendSignal(1,'D',false);
          LampD_Status=0;
          iosController.writeMessage("LampD",LampD_Status);
          
          actionTransmitter.sendSignal(1,'C',false);
          LampC_Status=0;
          iosController.writeMessage("LampC",LampC_Status);
          
          actionTransmitter.sendSignal(1,'B',false);
          LampB_Status=0;
          iosController.writeMessage("LampB",LampB_Status);
          
          actionTransmitter.sendSignal(1,'A',false);
          LampA_Status=0;          
          iosController.writeMessage("LampA",LampA_Status);
        
        sendSwitchStatus(); //Update the switch status each time a command has been received to be send with RF12
         
        RemoteReceiver::enable(); //enable the remote receiver.
}

