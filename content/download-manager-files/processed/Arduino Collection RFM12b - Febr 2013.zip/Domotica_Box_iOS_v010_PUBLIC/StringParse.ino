void StringParse(String inputString){
 
  
    String TMP_Message = inputString.substring(6); // start reading at position 6 (TX868=V1,value,value,value and so on)
    char msg[TMP_Message.length()+1];
    TMP_Message.trim();
    TMP_Message.toCharArray(msg,TMP_Message.length()+1);

    int j=0;
    for(int i=0;i<TMP_Message.length() && j<10;i++){
      
      if(msg[i] != ',')
        Text[j] += msg[i];
      else if(msg[i] == ','){
        Text[j] += '\0';
        j++;
      }
    }        
      GetDataFromArray(); //Get data from the array and process data
      
      for(int y=0;y<10;y++){ // erase array after processing with GetDataFromArray()
        Text[y]="";
      }
    
 
     
 }
 
 
byte GetDataFromArray(){ //add more IF statements (and enlarge Text Array when more variables are to be processed)
                         //this function only process the data from array and store in struct variables. 
  
  
    if(Text[0] == "V1"){
      char value[Text[1].length()+1];
      Text[1].toCharArray(value,Text[1].length()+1);
      outData_1.actual=atoi(value);
      
      char value1[Text[2].length()+1];
      Text[2].toCharArray(value1,Text[2].length()+1);
      outData_1.today=atoi(value1);
      
      char value2[Text[3].length()+1];
      Text[3].toCharArray(value2,Text[3].length()+1);
      outData_1.peak=atoi(value2);
      
      char value3[Text[4].length()+1];
      Text[4].toCharArray(value3,Text[4].length()+1);
      outData_1.total=atoi(value3);
      
      char value4[Text[5].length()+1];
      Text[5].toCharArray(value4,Text[5].length()+1);
      outData_1.TotalActual = atoi(value4);
      
      char value5[Text[6].length()+1];
      Text[6].toCharArray(value5,Text[6].length()+1);
      outData_1.Nactual = atoi(value5);
    
      char value6[Text[7].length()+1];
      Text[7].toCharArray(value6,Text[7].length()+1);
      outData_1.NactualReturn = atoi(value6);
    
      char value7[Text[8].length()+1];
      Text[8].toCharArray(value7,Text[8].length()+1);
      float GasTmp = atof(value7);
      outData_1.GasUsage = GasTmp * 1000; //create long instead of float (i.e liters instead of Quub)    
      
      char value8[Text[9].length()+1];
      Text[9].toCharArray(value8,Text[9].length()+1);
      outData_1.NetToday = atoi(value8);
      
      PendingOutputSolar = SOLAR_STRUCT;

   //   return(SOLAR_STRUCT);
    }
    
    
  //******* Process SunMoon Times ********
   if(Text[0] == "SUN"){
         
      Text[1].toCharArray(outData_2.sunrise,6);
      Text[2].toCharArray(outData_2.sunset,6);
      Text[3].toCharArray(outData_2.moonrise,6);
      Text[4].toCharArray(outData_2.moonset,6); 
      
      PendingOutputSun = SUNTIMES_STRUCT;

    //  return(SUNTIMES_STRUCT); // return the WhichStruct type number. Used in PendingOutput.
   }
   
     //******* Process SunMoon Times ********
   if(Text[0] == "TIME"){
         
      char value9[Text[1].length()+1];
      Text[1].toCharArray(value9,Text[1].length()+1);
      outData_8.time=atol(value9);      
      
      PendingOutputTime = TIME_STRUCT;
   }
}

//add additional IF statements in case you need more data to be processed by the domoticabox. So when you receive more commands
// via LAN just add IF(Text[0] == "commandname") and process the data. V1, SUN and TIME are an example above.


 
