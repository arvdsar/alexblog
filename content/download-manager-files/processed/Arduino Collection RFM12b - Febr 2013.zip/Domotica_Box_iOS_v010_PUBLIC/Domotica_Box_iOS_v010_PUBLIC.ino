

/*
Domotica Gateway by Alexander van der Sar - http://www.vdsar.net
this device is a connection hub between internet, other Arduino's or Raspberry PI('s).
Relays, wireless transmitters or other sensors or output device can be connected to this device.

The device listens on a ethernet port for commands to be executed. Commands switches digital ports,
read analog data or send wireless data. Anything can be programmed in this device. 

You have to change it to suit your needs so you need to be able to read the code and do some electronics.



Changelog:
v0.1 - 10 october 2012 - the initial version using ethernet and switch basic devices
v0.2 - 12 october 2012 - added Arduino Manager using IOSController.h (v1.5.1 minimal) (buy from iStore). Added support for iOS and MAC OS control. Split in multiple files
v0.2a - 20 october 2012 - added minor delay of 2 seconds in ProcessMessage to reduce overhead in sending data to iOS.
v0.2b - 20 october 2012 - added 'bedtijd' delayed turn off lights using MsTimer2.h library
v0.2c - 20 october 2012 - added sync of switches for iOS devices
v0.3 - 21 october 2012 - added 434Mhz Receiver. This will receive commands from the 434mhz remotes and trigger the commands in the Arduino which will send commands 
        via 434mhz to the receivers. Goal is better reach of the remotecontrols and now the Arduino always knows the state of the switches
        with the assumption that if you press a button on the remote and a light does not switch on, you repeat this action. 
0.4 - 21 october 2012 - added ToLCD file with function to transfer switch status to LCD display. (in progress)
0.4a - 23 october 2012 - added receiver to interface remote controlling.
0.4b - 23 october 2012 - added iOS message update to update switch status when using remote control
0.4c - 26 october 2012 - added timing millis() to monitor speed
0.4d - 27 october 2012 - optimized if statements
0.4e - 27 october 2012 - more IF optimazations and cleanup
0.5 - 27 october 2012 - clean up of unnecessary Serial.print commands that crashed the code, check the code for use of interrupts(); 
0.5c - 12 november 2012 - Added functionality for receiving VARIABLES like moonrise e.d.
0.5d - 12 november 2012 - created TX434send function to send data
0.5e - 13 november 2012 - optimzed code with TX434 Send, added delay to TX434Send to give receiver some slack and added
      sunmoon data transfer to standard TX434
0.5f - 19 november 2012 - Since v020 of LCDDisplay_434mhz, it is necessary to close received strings with a comma (like domo,2343, )
0.6 - 2 december - Implemented new format in which data is received from the environment 
      (TX434=v1,value,value,value instead of TX434=Variable,value,variable,value. Make it more efficient"
v0.6a - 4 december - fixed a issue where domo value was send after each transmission. (if statement was incomplete)      
v0.6b - 6 december - NetToday Added
v0.7 - 6 december - PushingBox API added. Added DNS Server in ethernet initialization
DOORBELL command:  sendToPushingBox(PushingBox_DEVID1); //Add this to some trigger and photo & mail will be send
v0.71 - 7 december - Added some (commented) code for analog doorbell interface. It turned out that the doorbell also sends a digital code that could already be read by 
      the standard 'controlling'  code implemented. Therefore just added another 'Switch/case' for the doorbell. Left analog code in main loop but commented out. 
v0.72 - 17 december - added LampF on code 123 / C for Christmas Tree ;-)
v0.8 - 3 januari 2013 - Changed Virtual Wire to RF12 library for RFM12b receiver. There is issue with using ethernet shield and RF12 library together
  http://thebillplease.net/play/fixing-arduino-ethernet-rfm12-communication/ tips are used to make it compatible
  (still to be tested). Hopefully it does not interfere with decent ethernet lib operation and so on.
v0.9 - since v0.8 tried to implement uploading data to thingspeak and cosm.com. This didn't work properly so removed this uploading functionality and build a
  a sensorbox to do the uploading to Open.Sen.Se. (or Thingspeak).
  Added a lost fix of v0.73 into this version to switch on/off the IP Cam.
  this version should work with solar monitor v09
v0.9b - Fixed SUNTIMES, Modified order in which structs are send, added TIME for sending unix time data over air to wireless LCD (TX868=TIME,1361221925)
v0.10 - Version Baseline. Same as v0.9b

  

Variable string to LCD display:
V1,actual,today,peak,total,TotalActual,Nactual,NactualReturn,GasUsage,NetToday,



Since of version v0.8 I switched from cheap 434mhz transmitters to a little more expensive (4 euro's) RFM12b transceivers using the RF12 library.
The cheap transmitters are still used to remote control switches with remoteswitch library.
Data can be send more easily using structs. To code is written so that you can send/receive different structs so more flexibility in what data you send. 
Below are the struct definitions:

which_Struct codes:
1. Solar Monitor data (outgoing)
2. Sun & moon rise/set times (outgoing)
3. sensor data (incomming)

*/

#define VERSION "V0.10 - Domotica Gateway - www.vdsar.net"
#include <RemoteTransmitter.h>
#include <RemoteReceiver.h>
#include <MsTimer2.h>
#include <Dhcp.h>
#include <Dns.h>
#include <Ethernet.h>
#include <EthernetClient.h>
#include <EthernetServer.h>
#include <EthernetUdp.h>
#include <util.h>
#include <SD.h>
#include <IOSController.h>
#include <HttpClient.h>

#include <JeeLib.h>
#include <Ports.h>

#include <SPI.h>
#include <DataStructure.h> 
#include "Userdefs.h"





// telnet defaults to port 23
EthernetServer server = EthernetServer(iOS_Port); //iOS Server
EthernetServer myserver = EthernetServer(MyServer_Port); //ethernet (telnet like) server
EthernetClient PushingBoxClient; //PushingBox client connection


//Define Strings & Pins

String readString; //String read from network
String TX_Message; //message to be transfered to LCD display
String TX_Message2; //2nd message used for sending domo switch status to lcd
String Text[11]={"","","","","","","","","","",""};



int doorbell;
unsigned long doorbelltime=0;
unsigned long int prev_millis;
  
int PTT_PIN = 13; // Ledje aan als 434mhz gaat zenden
int TX_PIN = 12; // TX pin van 434 mhz zender
int RX_INTERRUPT = 1; // Interrupt 0 = pin 2 for RX pin of 434 mhz receiver (using interrupt)

int RELAY1 = 42;  // Relays for gardenlights
int RELAY2 = 44;
int RELAY3 = 46;
int RELAY4 = 48; 

boolean LampA_Status=0; //status for remotecontrolled switches. Unreliable but when switched by this program, status is updated.
boolean LampB_Status=0;
boolean LampC_Status=0;
boolean LampD_Status=0;
boolean LampE_Status=0;
boolean LampF_Status=0;
boolean DeurAchter_Status=0;
boolean TuinAchter_Status=0;
boolean IPCam1_Status=1;

long DomoStatus=0;
boolean no_SendSwitchStatus=0;
float outdoorTemp,indoorTemp;
int nodeID;




MilliTimer sendTimer;
//byte pendingOutput=0;
byte PendingOutputSolar=0;
byte PendingOutputSun=0;
byte PendingOutputTime=0;

//************************** Structs to be send or received with RF12 **********************
//structs are defined in DataStructure.h


Payload_1 outData_1; // solarmonitor
Payload_2 outData_2; // sun/moontimes
Payload_3 inData_3; //tempsensor data
Payload_8 outData_8; //time sync data


ActionTransmitter actionTransmitter(TX_PIN);
ElroTransmitter elroTransmitter(TX_PIN);
//KaKuTransmitter kaKuTransmitter(TX_PIN);
//BlokkerTransmitter blokkerTransmitter(TX_PIN);

/*
 * Prototypes of IOSController’s callbacks
 *
 */
void doWork();
void doSync(char *variable);
void processIncomingMessages(char *variable, char *value);
void processOutgoingMessages();
void processAlarms(char *variable);
void deviceConnected();
void deviceDisconnected();


/*
 * IOSController Library initialization
 */
#ifdef ALARMS_SUPPORT 
  IOSController iosController(&server,&doWork,&doSync,&processIncomingMessages,&processOutgoingMessages,&processAlarms,&deviceConnected,&deviceDisconnected);
#else
  IOSController iosController(&server,&doWork,&doSync,&processIncomingMessages,&processOutgoingMessages,&deviceConnected,&deviceDisconnected);
#endif

 


void setup(){
 Serial.begin(9600);
 Serial.println(F("Starting Domotica Gateway"));
 Serial.println(VERSION);
 
  outData_1.which_Struct = SOLAR_STRUCT;
  outData_2.which_Struct = SUNTIMES_STRUCT;
  outData_8.which_Struct = TIME_STRUCT;

   //initialize RFM12b transceiver. Before network init for compatibility reasons
  rf12_initialize(NODEID, FREQBAND, NETGROUP);  
  
    // initialize the ethernet device
  Ethernet.begin(mac, ip, dnsserver, gateway, subnet);
  // start listening for clients
  server.begin();
  
  
 //*********** Initialize KlikAan/KlikUit / Action remote control receivers *********** 
   // Initialize receiver on interrupt 0 (= digital pin 2), calls the callback "showCode"
  // after 3 identical codes have been received in a row. (thus, keep the button pressed
  // for a moment)
  //
  // See the interrupt-parameter of attachInterrupt for possible values (and pins)
  // to connect the receiver.
  RemoteReceiver::init(RX_INTERRUPT, 3, ReceiveRemoteControl);  //int 1 op pin 3 
  
  
  pinMode(PTT_PIN, OUTPUT); 
  pinMode(RELAY1, OUTPUT);
  pinMode(RELAY2, OUTPUT);
  pinMode(RELAY3, OUTPUT);
  pinMode(RELAY4, OUTPUT);
  
  //relays work inversed. False = on, true = off. Switch them off at start of Arduino
  digitalWrite(RELAY1,true);
  digitalWrite(RELAY2,true);
  digitalWrite(RELAY3,true);
  digitalWrite(RELAY4,true);
  
  sendToPushingBox(PushingBox_DEVID2); //Send ProwlApp alert that Domotica Gateway has restarted

 digitalWrite(A0, HIGH);  // set pullup on analog pin 0 for doorbell interface
 outData_1.Doorbell = 0;

}

void loop(){
//only call iosController loop. ALL regular work goes into doWork() function instead of loop!
  Process_RF12(); //continiously check for incomming RF12 data and send data when it is available

  iosController.loop(450);

 }

void doWork(){  //This is the IOSController 'replacement' for the arduin loop() function.

  // if an incoming client connects, there will be bytes available to read:
 doorbell=analogRead(0);
 
 if(doorbell < 1000 && millis() > doorbelltime+20000){
       outData_1.Doorbell = 1; //set doorbell in struct on TRUE
       PendingOutputSolar=SOLAR_STRUCT; //set pending output on 1 so that RF12_Process will process the data 

       sendToPushingBox(PushingBox_DEVID1);
       doorbelltime = millis();
     // Process_RF12(); //be sure that RF12 signal is send directly
     // outData_1.Doorbell = 0; //unset doorbell in struct to FALSE     
       
       Serial.println("Doorbell via analog port activated");
   }
   
   if(millis() > doorbelltime + 18000) //reset doorbell to 0 after 18 seconds
     outData_1.Doorbell = 0;

     
   
  // Serial.print("Doorbell value");
 // Serial.println(analogRead(0)); 
 
  EthernetClient myclient = myserver.available();
  
  
  if (myclient){
    //Serial.print("Connected myclient on port: ");
    //Serial.println(MyServer_Port);
    
    while (myclient.available()) { //as long as data is available to read
        char c = myclient.read();
        readString += c;
     }
   
   readString.trim(); //remove whitespaces from created readString. 
   Serial.print("readString == ");
   Serial.println(readString); //for debugging
   
   StartSwitching(readString);
   
   readString = ""; //clean readString to receive new command via network
     
   if (!myclient.connected()) {
      myclient.stop();  
      //Serial.print("Disconnected myclient on port: ");
      //Serial.println(MyServer_Port);
      }
  } 
  
  
}


void doSync (char *variable) {
/*
  if (strcmp(variable,"Knob1")==0) {

    iosController.writeMessage(variable,map(servo.read(),0,180,0,1023));
  }
*/

// When adding a new variable (like LampF or so, also add it to the controlling file to immediately update iOS switch)
  if (strcmp(variable,"TuinVoor")==0) 
    iosController.writeMessage(variable,!digitalRead(RELAY1)); //true == off, false == on
  
  else if (strcmp(variable,"TuinMidden")==0) 
    iosController.writeMessage(variable,!digitalRead(RELAY2));
    
  else if (strcmp(variable,"DeurRechts")==0) 
    iosController.writeMessage(variable,!digitalRead(RELAY3));
   
  else if (strcmp(variable,"DeurLinks")==0) 
    iosController.writeMessage(variable,!digitalRead(RELAY4));
  
    else if (strcmp(variable,"LampA")==0) 
    iosController.writeMessage(variable,LampA_Status);
  
    else if (strcmp(variable,"LampB")==0) 
    iosController.writeMessage(variable,LampB_Status);
  
    else if (strcmp(variable,"LampC")==0) 
    iosController.writeMessage(variable,LampC_Status);
  
    else if (strcmp(variable,"LampD")==0) 
    iosController.writeMessage(variable,LampD_Status);
  
    else if (strcmp(variable,"LampE")==0) 
    iosController.writeMessage(variable,LampE_Status);
    
    else if (strcmp(variable,"LampF")==0) 
    iosController.writeMessage(variable,LampF_Status);
  
    else if (strcmp(variable,"TuinAchter")==0) 
    iosController.writeMessage(variable,TuinAchter_Status);
  
    else if (strcmp(variable,"DeurAchter")==0) 
    iosController.writeMessage(variable,DeurAchter_Status);  
 
}



/**
*
*
* This function is called periodically and messages can be sent to the iOS device
*
*/
void processOutgoingMessages() {

  
  if(millis() - 2500 >= prev_millis){  // eens per 2,5 seconden de waarden updaten naar iOS.
  iosController.writeMessage("Actual",outData_1.actual);
  iosController.writeMessage("Peak", outData_1.peak);
  iosController.writeMessage("Today", outData_1.today);
  iosController.writeMessage("Total", outData_1.total);
  iosController.writeMessage("Consumption", outData_1.TotalActual);
  iosController.writeMessage("Import", outData_1.Nactual);
  iosController.writeMessage("Export", outData_1.NactualReturn);
  iosController.writeMessage("GasUsage", outData_1.GasUsage);
  iosController.writeMessage("NetToday", outData_1.NetToday);
  iosController.writeMessage("outdoorTemp", outdoorTemp);
  iosController.writeMessage("indoorTemp", indoorTemp);

    
      
  prev_millis = millis(); 
  }
   

}

/**
*
*
* This function is called when a Alarm is fired
*
*/
void processAlarms(char *alarm) {
  
  Serial.print(alarm);
  Serial.println(" fired");
  
}

/*
*
* This function is called when the iOS device connects
*/
void deviceConnected () {

 Serial.println("iOS Device Connected");
}

/**
*
* This function is called when the iOS device disconnects
*/
void deviceDisconnected () {

  Serial.println("iOS Device Disconnected");
}

  

    

