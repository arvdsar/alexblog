
////
//
// General code from http://www.pushingbox.com for Arduino + Ethernet Shield (official) v1.2
//
////

//Your secret DevID from PushingBox.com. You can use multiple DevID on multiple Pin if you want



/* Just keep it for reference. Don't need it probably ;) ??
{

        sendToPushingBox(PushingBox_DEVID1);
    
      
      
      //DEBUG part
      // this write the respons from PushingBox Server.
      // You should see a "200 OK"
      if (PushingBoxClient.available()) {
        char c = PushingBoxClient.read();
        if(DEBUG){Serial.print(c);}
      }
      
      // if there's no net connection, but there was one last time
      // through the loop, then stop the client:
      if (!PushingBoxClient.connected() && lastConnected) {
        if(DEBUG){Serial.println();}
        if(DEBUG){Serial.println("disconnecting.");}
        PushingBoxClient.stop();
      }
      lastConnected = client.connected();
}

*/
//Function for sending the request to PushingBox

void sendToPushingBox(char devid[]){
  //PushingBoxClient.stop();
  Serial.println(F("connecting..."));

  if (PushingBoxClient.connect(PushingBoxServer, 80)) {
    Serial.println(F("connected to PushingBox"));

    Serial.println(F("sendind request"));
    PushingBoxClient.print("GET /pushingbox?devid=");
    PushingBoxClient.print(devid);
    PushingBoxClient.println(" HTTP/1.1");
    PushingBoxClient.print("Host: ");
    PushingBoxClient.println("api.pushingbox.com");
    PushingBoxClient.println("User-Agent: Arduino");
    PushingBoxClient.println();
    Serial.println("sendind request send");
    PushingBoxClient.stop();
    Serial.println(F("Disconnected from PushingBox"));

  }
  else {
    Serial.println(F("connection to PushingBox failed"));
  }
}
