void DisplayData(int Screen){
 
  

//************************* Display Verbruik & Tijd & Temperatuur ****************************
if(Screen == 0 && message ==""){
  
  vertraging = 10000; //show this display for 10 seconds
  
  Display_TopBar(); //Top row of LCD display with actual generation and consumption
  
  lcd.setCursor(15,2);
  lcd.print(float(outData_3.temp)/100,1); // the ,1 is to limit 0,1 instead of 0,10
  lcd.print((char)223);
  lcd.setCursor(15,3);
  lcd.print(float(outData_3.humidity)/100,1);
  lcd.print("%");
  
  lcd.setCursor(0,2);
  lcd.print(hour());
  printDigits(minute());
  lcd.setCursor(0,3);
  //lcd.print(dayStr(weekday()));
  lcd.print(dayShortStr(weekday()));
  lcd.print(" ");
  lcd.print(day());
  lcd.print(" ");
  lcd.print(monthShortStr(month()));
  Display_Watchdog();

}
  //************************** Overzicht all values *************************
  
else if(Screen == 1 && message ==""){
   
  vertraging = 10000; //show this display for 10 seconds


  lcd.setCursor(0,0);
  lcd.print(F("A: "));
  lcd.setCursor(8-strlen(actual),0);
  lcd.print(actual);
  lcd.print(F("W   C:")); 
 // lcd.setCursor(11,0);
 // lcd.print("C: ");
  lcd.setCursor(19-strlen(TotalActual),0);
  lcd.print(TotalActual);
  lcd.print(F("W"));
  
  lcd.setCursor(0,1);
  lcd.print(F("P: "));
  lcd.setCursor(8-strlen(peak),1);
  lcd.print(peak);
  lcd.print(F("W   I:"));
  // lcd.setCursor(11,1);
  //lcd.print("I: ");
  lcd.setCursor(19-strlen(Nactual),1);
  lcd.print(Nactual);
  lcd.print(F("W"));
  
  lcd.setCursor(0,2);
  lcd.print(F("T: "));
  lcd.setCursor(8-strlen(today),2);
  lcd.print(today);
  lcd.print(F("Wh  E:"));
 // lcd.setCursor(11,2);
 // lcd.print("E: ");
  lcd.setCursor(19-strlen(NactualReturn),2);
  lcd.print(NactualReturn);
  lcd.print(F("W"));
  
  
  lcd.setCursor(0,3);
  lcd.print(F("L: "));
  lcd.setCursor(8-strlen(total),3);
  lcd.print(total);
  lcd.print(F("kWh G:"));
 // lcd.setCursor(19-strlen(GasTmp)-strlen(GasRest)-1,3); //lengte voor, achter de komma en de komma
  lcd.setCursor(19-strlen(GasUsage),3);
  //lcd.print(GasTmp); //voor de komma
  //lcd.print(".");
  //lcd.print(GasRest); //achter de komma
  lcd.print(GasUsage);
  lcd.print(F("Q"));
  
  Display_Watchdog();
}

//************** Temperature overview *******************
 
 else if(Screen == 2){
    vertraging = 10000; //show this display for 5 seconds
     
    lcd.setCursor(0,0);
    lcd.print(F("In:   "));
    lcd.print(float(outData_3.temp)/100,1); // the ,1 is to limit 0,1 instead of 0,10
    lcd.print((char)223);
    lcd.print(" ");
    lcd.print(float(outData_3.humidity)/100,1);
    lcd.print("%");   
    lcd.setCursor(0,1);
      
    if((outdoor_temp >= 0) && (outdoor_temp < 10))
        lcd.print(F("Out:   "));
    else if((outdoor_temp > -10) && (outdoor_temp < 0))
        lcd.print(F("Out:  "));
    else if(outdoor_temp <= -10)
        lcd.print(F("Out: "));
    else 
        lcd.print(F("Out:  "));

    lcd.print(outdoor_temp,1); // the ,1 is to limit 0,1 instead of 0,10
    lcd.print((char)223);
    lcd.print(" ");
    lcd.print(outdoor_humidity,1);
    lcd.print("%");   
    lcd.setCursor(0,2);
    lcd.print(F("Elin: "));
    lcd.print(kid_temp,1); // the ,1 is to limit 0,1 instead of 0,10
    lcd.print((char)223);
   //  lcd.print(" ");
   // lcd.print(kid_humidity,1); //the current sensor does not support humidity yet.
  //  lcd.print("%");   
  
 }
 

//******************** DOMOTICA STATUS  ***********************
else if(Screen == 3 && message == ""){ // Domotica lights status

  vertraging = 5000; //show this display for 5 seconds

  
  Display_TopBar(); //Top row of LCD display with actual generation and consumption

  lcd.setCursor(0,2);
  lcd.print(F("Light: "));
  lcd.print(LampA_Status);
  lcd.print(LampB_Status);
  lcd.print(LampC_Status);
  lcd.print(LampD_Status);
  lcd.print(LampE_Status);
  lcd.setCursor(0,3);
  lcd.print(F("Tuin: "));
  lcd.print(TuinVoor_Status);
  lcd.print(TuinMidden_Status);
  lcd.print(TuinAchter_Status);
  lcd.print(DeurAchter_Status);
  lcd.print(DeurLinks_Status);
  lcd.print(DeurRechts_Status);
 
 Display_Watchdog();
}



//************************ MOON & SUN Times **********************

else if(Screen == 4 && message == ""){ //display sun & moon set/rise times
  
    vertraging = 5000; //show this display for 5 seconds

  
    
  Display_TopBar(); //Top row of LCD display with actual generation and consumption
  lcd.setCursor(0,2);
  lcd.print(F("Sun:  "));
  lcd.setCursor(11-strlen(inData_2.sunrise),2);
  lcd.print(inData_2.sunrise);
  lcd.print(" - ");
  lcd.setCursor(19-strlen(inData_2.sunset),2);
  lcd.print(inData_2.sunset);
  lcd.setCursor(0,3);
  lcd.print(F("Moon: "));
  lcd.setCursor(11-strlen(inData_2.moonrise),3);
  lcd.print(inData_2.moonrise);
  lcd.print(" - ");
  lcd.setCursor(19-strlen(inData_2.moonset),3);
  lcd.print(inData_2.moonset);
  
  Display_Watchdog();
  
}
  
  
  //******************** ALL FINANCIAL VALUES *****************
  
 else if(Screen == 5 && message ==""){
   
  vertraging = 10000; //show this display for 10 seconds

  peakCosts = atof(peak);
  peakCosts = (peakCosts / 1000) * kWhCosts;
  
  todayCosts = atof(today);
  todayCosts = (todayCosts/1000) * kWhCosts; 
  
  TotalActualCosts = atof(TotalActual);
  TotalActualCosts = (TotalActualCosts / 1000)*kWhCosts;
  
  NetTodayCosts = atof(NetToday);
  NetTodayCosts = (NetTodayCosts / 1000) * kWhCosts;
  
  totalCosts = atof(total);
  totalCosts = totalCosts * kWhCosts;
  
  GasUsageCosts = float(inData_1.GasUsage);
  GasUsageCosts = ((GasUsageCosts/1000) * m3Costs);
  
  lcd.setCursor(0,0);
  lcd.print(F("P$: "));
  lcd.print(peakCosts);
  lcd.setCursor(11,0);
  lcd.print(F("C$: "));
  lcd.print(TotalActualCosts);
  
  
  lcd.setCursor(0,2);
  lcd.print(F("T$: ")); 

  lcd.print(todayCosts,2);
  
  lcd.setCursor(11,2);
  lcd.print(F("N$: "));
  lcd.print(NetTodayCosts,2);
  
  lcd.setCursor(0,3);
  lcd.print(F("L$: "));
  lcd.print(totalCosts,2);
    
  lcd.setCursor(11,3); 
  lcd.print(F("G$: "));
  lcd.print(GasUsageCosts,2);
 
  Display_Watchdog();
}  
 
 
 //******************** DOORBELL RING & DISPLAY ****************
 
 else if(Screen == 6){
    
   vertraging = 20000;
         Serial.println("Melody aanroepen");
        
       //  interrupts();      

         lcd.clear();
         lcd.display();
         lcd.setCursor(0,1);
         lcd.print(F("ER WORDT AANGEBELD"));
         lcd.setCursor(0,3);
         lcd.print(F("DEUR OPENEN SVP"));
// playing melody is called within loop() function to avoid interrupt missery
        // delay(2000);

         
 }
// ******************* MESSAGE DISPLAY ************************

else if (screen == 7){
  //implement some scrolling mechanism.
  //lcd.clear();
  lcd.setCursor(0,1);
  lcd.print(message);
  
  
 // message= "";
}
  
 
}

//****************** DISPLAY TOP BAR ***************************
void Display_TopBar(){

if(atoi(actual) == 0){
    lcd.setCursor(0,0);
    lcd.print(F("Geen zon"));
    
  }
  else if(atoi(actual) >= 2500){
  lcd.setCursor(0,0);
  lcd.print(F("*** "));
  lcd.setCursor(7-strlen(actual),0);
  lcd.print(actual);
  lcd.print(F("W"));
  }
  else if(atoi(actual) >= 1500){
  lcd.setCursor(0,0);
  lcd.print(F("** "));
  lcd.setCursor(7-strlen(actual),0);
  lcd.print(actual);
  lcd.print(F("W"));
  }
  else if(atoi(actual) >= 100){
  lcd.setCursor(0,0);
  lcd.print(F("*"));
  lcd.setCursor(7-strlen(actual),0);
  lcd.print(actual);
  lcd.print(F("W"));
  }
  else if(atoi(actual) > 0){
  lcd.setCursor(0,0);
 // lcd.print("");
  lcd.setCursor(7-strlen(actual),0);
  lcd.print(actual);
  lcd.print(F("W"));
  }
  
  
  TotalActualCosts = atof(TotalActual);
  TotalActualCosts = (TotalActualCosts / 1000)*kWhCosts;
  lcd.setCursor(9,0);
  lcd.print(F("$"));
  lcd.print(TotalActualCosts,2);
  lcd.setCursor(20-(strlen(TotalActual)+1),0);
  lcd.print(TotalActual);
  lcd.print(F("W"));
  

  
}

//  ********   FTOA*******

char *ftoa(char *a, double f, int precision)
{
  long p[] = {0,10,100,1000,10000,100000,1000000,10000000,100000000};
  
  char *ret = a;
  long heiltal = (long)f;
  itoa(heiltal, a, 10);
  while (*a != '\0') a++;
  *a++ = '.';
  long desimal = abs((long)((f - heiltal) * p[precision]));
  itoa(desimal, a, 10);
  return ret;
}

