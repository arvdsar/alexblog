void Struct2ASCII(){
  
itoa(inData_1.actual,actual,10);
itoa(inData_1.peak,peak,10);
itoa(inData_1.today,today,10);
ltoa(inData_1.total,total,10);
itoa(inData_1.NactualReturn,NactualReturn,10);
itoa(inData_1.Nactual,Nactual,10);
//itoa(inData_1.Nreturn,Nreturn,10);
//itoa(inData_1.Npeak,Npeak,10);
//itoa(indata1.NetToday,NetToday,10);
//itoa(indata1.TotalToday,TotalToday,10);

ftoa(GasUsage,float(inData_1.GasUsage)/1000,2);
itoa(inData_1.TotalActual,TotalActual,10);
  
  
  
  
}
