

/*
Wireless LCD Display module. Receive data via 434Mhz and display text on an LCD display.
Should run on Arduino Nano

Changelog:
v0.1 - 13 october 2012 - Initial version.
v0.2 - 15 october 2012 - working on 16x2 display
v0.3 - 21 october 2012 - added long domo variable that contains status of switches received from domotica box
This should be an & or | statement to get correct values.
v0.5 - 26 october 2012 - Added watchdog for received messages. If no data is received, after 90 seconds a X will appear on line 2 position 15
v0.6 - 26 october 2012 - added DHT11 temperature sensor
v0.7 - 28 october 2012 - added DS1307 RTC
v0.8 - 12 november 2012 - added sun & moon rise/set time reception 
v0.9a dht22 - 17 november 2012 - Used another DHT library to be compatible with DHT11, DHT21, DHT22. Changed code to use DHT22
v0.20 - 19 november - Changed from using String object to char Arrays. Strings seem to have issues.
v0.21 - 22 november - LCD Display for 20x4 build
v0.22 - 2 december - Added LDR to detect environment Light (Use as switch or dim display ?!?!)
v0.23 - 2 december - implemented another data reception structure. Now there is one indicator received and variables are fixed positions in the array
v0.24 - 4 december - added function to create topbar in display (with actual and consumption), fixed watchdog again for data received, variable time per display item
v0.25 - 5 december - Memory friendly - added tekst to flash by using F("tekst"); Also added lcd.display() to turn display on each time a new screen is showed
        this should not be necessary but with both memory friendly and lcd.display() the display keeps working.
v0.26 - 5 december - Added financial impact, euro's added.
v0.27 - to do: value NetToday should be send from EnergyMonitor with value V3. 
V0.28 - 7 december - Doorbell command (DB,) received via 434mhz displays text and plays a melody for 40 seconds
V0.30 - 22 december - Redesign based on v0.28 to make more efficient, prevent corruption of display and so on. turned out that using timer2 made arduino instable.
v0.31 - 23 december - removed timer2 usage for display watchdog, removed unnecessary code. Removed receiver stop/start in display code. If display becomes corrupted add it again.
v0.40 - 18 januari 2013 - based on version v0.31, changed virtual wire to RF12 library using RFM12b transceivers. (also in my case using 868 mhz instead of 434mhz.
v0.42 - 18 februari 2013 - removed some bugs and added outdoor temp display
v0.43 - 18 februari 2013 - added TIME struct for receiving unix time to set RTC & DS1307 (TX868=TIME,1361221925)
v0.44 - 19 februari 2013 - fixed doorbell ringing 


To Do: 
- implementeren van een scroll mechanisme voor messages
- drukknopje om door opties te springen

Variable receive strings. This is the structure in which variables are received:
(TX868= is removed by the domotica gateway and therefore not received by the LCD Display unit)

V1,actual,today,peak,total,TotalActual,Nactual,NactualReturn,GasUsage,NetToday,

*/

//#include <LiquidCrystal.h>  //replaced by LCD library in jeelib.h. 
#include <JeeLib.h>
#include <DHT.h>
#include <Time.h>
#include <Wire.h>
#include <DS1307RTC.h>
#include "pitches.h"
#include <PortsLCD.h>
#include <DataStructure.h> 



// notes in the melody:
//int melody[] = {
 // NOTE_C4, NOTE_G3,NOTE_G3, NOTE_A3, NOTE_G3,0, NOTE_B3, NOTE_C4};

//Jingle bells  
int melody[] = { 
NOTE_E4, NOTE_E4,NOTE_E4,0,NOTE_E4, NOTE_E4,NOTE_E4,0, NOTE_E4, NOTE_G4, NOTE_C4, NOTE_D4, NOTE_E4};


// note durations: 4 = quarter note, 8 = eighth note, etc.:
//int noteDurations[] = {
// 4, 8, 8, 4,4,4,4,4 };
 
//Jingle Bells
int noteDurations[] = {
  4,4,4,4  , 4,4,4,4, 4,4,4,4, 2 };

#define DHTPIN 3  //pin voor DHT temp sensor  (digital)
#define LDRPIN 2  //pin voor LDR Light sensor (analog)

// Uncomment whatever type you're using!
//#define DHTTYPE DHT11   // DHT 11 
#define DHTTYPE DHT22   // DHT 22  (AM2302)
//#define DHTTYPE DHT21   // DHT 21 (AM2301)

DHT dht(DHTPIN, DHTTYPE);

// initialize the library with the numbers of the interface pins
LiquidCrystal lcd(9,8,7,6,5,4);


//String actual,peak,today,total;
char actual[6];
char peak[6];
char today[6];
char total[6];

//values from 'slimme meter';
char NactualReturn[6]; //actuele teruglevering
char Nactual[6]; //actueel vermogen uit net
char Nreturn[6]; //teruglever vermogen naar net
char Npeak[6]; //piek vermogen gedurende xx minuten
char NetToday[6]; //totaal vermogen verbruikt vandaag
char TotalToday[6]; // totaal meterstand
char GasUsage[6]; // Gas verbruik op huidige dag
char TotalActual[6]; //Actueel energie verbruik woning



float TotalActualCosts;
float kWhCosts=0.21; //price per kWh electricity (only 'enkeltarief')
float GasUsageCosts;
float m3Costs=0.56; //Price per m3 gas
float totalCosts;
float todayCosts;
float NetTodayCosts;
float peakCosts;
long domo=0;
int GasTmp=0;
int GasRest=0;

String message;

unsigned long NoDataReceived = 0;
int nodeID; //node ID of header received

float outdoor_temp=0;
float outdoor_humidity=0;
float kid_temp=0;
float kid_humidity=0;

char LampA_Status = ' ';
char LampB_Status = ' ';
char LampC_Status = ' ';
char LampD_Status = ' ';
char LampE_Status = ' ';
char LampF_Status = ' ';
char TuinVoor_Status = ' ';
char TuinMidden_Status = ' ';
char DeurLinks_Status = ' ';
char DeurRechts_Status = ' ';
char DeurAchter_Status = ' ';
char TuinAchter_Status = ' ';

int button = 3;
int screen = 0;
unsigned long vorigeMillis = 0;
unsigned long vorigeMillis2 = 0;
unsigned long vorigeMillis3 = 0;

int cnt=0;
float humidity,temp;

unsigned long vertraging = 10000;



//2D char Array. initialise with 10 characters + zero
char* Text[]={"aaaaaaaaaa","bbbbbbbbbb","cccccccccc","dddddddddd","eeeeeeeeee","ffffffffff"};//"gggggggggg","hhhhhhhhh","iiiiiiiiii","jjjjjjjjjj","kkkkkkkkkk"};

/*
char sunset[6];
char sunrise[6];
char moonset[6];
char moonrise[6];
*/

//*********************************** DEFINE RF12 WIRELESS SETTINGS ******************
// ID 0 is reserved for OOK use
// node ID 31 is special because it will pick up packets for any node (in the same netGroup). 
#define NODEID    1
#define FREQBAND  RF12_868MHZ 
#define NETGROUP    201
#define ALT_NODEID   1 // alternative NODE ID included in Struct (not in header, that is NODEID). To be used when you send data to specific node, then this should contain origination node number

MilliTimer sendTimer;
byte pendingOutput=0;


//************************** Structs to be send or received with RF12 **********************
// defined in DataStructure.h

Payload_1 inData_1; // solarmonitor
Payload_2 inData_2; // sun/moontimes
Payload_3 inData_3,outData_3; //sensordata
Payload_8 inData_8; //time sync data

//optie om te implementeren, kamertemperatuur data als sensordata versturen.

#define SOLAR_STRUCT 1  //this defines the struct. Used in RF12, Getdatafromarray() to identify pendingoutput en ID the structure to be send
#define SUNTIMES_STRUCT 2
#define TEMP_STRUCT 3
#define SENSOR_STRUCT 4

void setup(){
   pinMode(button, INPUT_PULLUP);   
  
  //Serial.begin(9600);
    Serial.println(F("started"));
    // set up the LCD's number of columns and rows:
    lcd.begin(20, 4);
    lcd.clear();
    lcd.print(F("Start W-LCD 0.44"));
    lcd.setCursor(0,1);
    lcd.print(F("www.vdsar.net"));
   
   rf12_initialize(NODEID, FREQBAND, NETGROUP);
  
    //get time from DS1307 RTC  
    setSyncProvider(RTC.get);   // the function to get the time from the RTC
    if(timeStatus()!= timeSet) {
       Serial.println(F("Unable to sync with the RTC"));
       lcd.setCursor(0,3);
       lcd.print(F("No RTC Sync"));
    }
     
    else{
       Serial.println(F("RTC has set the system time"));
       lcd.setCursor(0,3);
       lcd.print(F("Time Set by RTC"));  
    }
  
  
  inData_1.Doorbell = 0; //set doorbell to 0
}


void loop(){
  
  Process_RF12(); //continiously check for incomming RF12 data and send data when it is available

  //Screen 6 means Doorbell !
  if(screen == 6){
             lcd.clear();
             DisplayData(screen);
             Melody();
             interrupts();
             //maybe some timing loop for re-ring doorbell?!?!?
  }
  

 if(millis() > vorigeMillis + vertraging) {  //cycle through the multiple display layouts
  vorigeMillis = millis();

   if(screen < 5) // 0, 1, 2 display layouts.
     screen++;
    else
     screen = 0; 

  }

 if(millis() > vorigeMillis2 + 3000){ //refresh display every 2 seconds (and read temperature too from DHT sensor (once per 2 seconds max)
    vorigeMillis2 = millis();
    getTemp(); //update temperature
    lcd.clear();
    DisplayData(screen);
  } 
  
if(millis() > vorigeMillis3 + 60000){  //send temperature info to sensorbox
  pendingOutput = TEMP_STRUCT; //outdata3 struct is filled with temp data. Set pending output to send it.
  vorigeMillis3 = millis();
  }  

}

 
void Display_Watchdog(){
       
    if(NoDataReceived+40000 < millis() ){
    lcd.setCursor(19,0);
    lcd.print("X");
    }
 }
 
  
void ProcessReceivedDomo(long Domo){
  
 
 LampA_Status = ' ';
 LampB_Status = ' ';
 LampC_Status = ' ';
 LampD_Status = ' ';
 LampE_Status = ' ';
 LampF_Status = ' ';
 TuinVoor_Status = ' ';
 TuinMidden_Status = ' ';
 DeurLinks_Status = ' ';
 DeurRechts_Status = ' ';
 DeurAchter_Status = ' ';
 TuinAchter_Status = ' ';

  if((Domo & 0x8000) == 0x8000)
    LampA_Status = 'A';  // 1000.0000.0000.0000
  if((Domo & 0x4000) == 0x4000)
    LampB_Status = 'B'; // 0100.0000.0000.0000
  if((Domo & 0x2000) == 0x2000)
    LampC_Status = 'C'; // 0010.0000.0000.0000
  if((Domo & 0x1000) == 0x1000)
    LampD_Status = 'D'; // 0001.0000.0000.0000
  if((Domo & 0x0800) == 0x0800)
    LampE_Status = 'E'; // 0000.1000.0000.0000
  if((Domo & 0x0400) == 0x0400)
    LampF_Status = 'F'; // 0000.0100.0000.0000
  if((Domo & 0x0200) == 0x0200) 
    TuinVoor_Status = 'V'; // 0000.0010.0000.0000   Tuinvoor
  if((Domo & 0x0100) == 0x0100)
    TuinMidden_Status = 'M'; // 0000.0001.0000.0000   TuinMidden
  if((Domo & 0x0080) == 0x0080)
    DeurLinks_Status = 'L'; // 0000.0000.1000.0000   Deurlinks
  if((Domo & 0x0040) == 0x0040)
    DeurRechts_Status = 'R'; // 0000.0000.0100.0000   Deurrechts
  if((Domo & 0x0020) == 0x0020)
    DeurAchter_Status = 'A'; // 0000.0000.0010.0000    
  if((Domo & 0x0010) == 0x0010)
    TuinAchter_Status = 'S'; // 0000.0000.0001.0000    
  
  
}
  
  
  

/*  
double dewPoint(double celsius, double humidity)
{
	double A0= 373.15/(273.15 + celsius);
	double SUM = -7.90298 * (A0-1);
	SUM += 5.02808 * log10(A0);
	SUM += -1.3816e-7 * (pow(10, (11.344*(1-1/A0)))-1) ;
	SUM += 8.1328e-3 * (pow(10,(-3.49149*(A0-1)))-1) ;
	SUM += log10(1013.246);
	double VP = pow(10, SUM-3) * humidity;
	double T = log(VP/0.61078);   // temp var
	return (241.88 * T) / (17.558-T);
}
*/

void printDigits(int digits){
  // utility function for digital clock display: prints preceding colon and leading 0
  lcd.print(":");
  if(digits < 10)
    lcd.print('0');
  lcd.print(digits);
}

void getTemp(){
   
  outData_3.humidity = dht.readHumidity()*100;
  outData_3.temp = dht.readTemperature()*100;
  outData_3.which_Struct = TEMP_STRUCT;
  outData_3.light = -99; //send non existing value for light level (no light sensor connected)
  
  if (isnan(outData_3.temp) || isnan(outData_3.humidity)) { //isnan (is not a number)
    lcd.setCursor(0,1);
    lcd.print(F("Failed to read DHT22"));
  } 
      
}


/*
  Melody
 
 Plays a melody
 
 circuit:
 * 8-ohm speaker on digital pin 8
 
 created 21 Jan 2010
 modified 30 Aug 2011
 by Tom Igoe

This example code is in the public domain.
 
 http://arduino.cc/en/Tutorial/Tone
 
 */
void Melody() { //play audio ;-)
  // iterate over the notes of the melody:
  for (int thisNote = 0; thisNote < 14; thisNote++) {

    // to calculate the note duration, take one second
    // divided by the note type.
    //e.g. quarter note = 1000 / 4, eighth note = 1000/8, etc.
    
    int noteDuration = 1000/noteDurations[thisNote];
    tone(1, melody[thisNote],noteDuration);  //(Pin 0, 100 ohm resistor and speaker)

    // to distinguish the notes, set a minimum time between them.
    // the note's duration + 30% seems to work well:
    int pauseBetweenNotes = noteDuration * 1.30;
    interrupts();
    delay(pauseBetweenNotes);
    noInterrupts();
    // stop the tone playing:
    noTone(1);
  }
}
