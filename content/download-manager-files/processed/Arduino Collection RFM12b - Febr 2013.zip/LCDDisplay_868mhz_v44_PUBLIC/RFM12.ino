//********* RF12 transceiver code *****
void Process_RF12(){
  
   if (rf12_recvDone() && rf12_crc == 0){ // && rf12_len == sizeof inData_3) {
        nodeID = rf12_hdr & 0x1F;  // get node ID from header

        //memcpy(&inData, (byte*) rf12_data, sizeof inData);
        procesInData(); //check which struct is being received, do the memcpy to struct and process data. then return.
        // optional: rf12_recvDone(); // re-enable reception right away
    }

    if (sendTimer.poll(100))
    
    if(pendingOutput == 0); //if no data to be send, don't do anything and therefore skip next 'else if'  statements.
 
       else if (pendingOutput == TEMP_STRUCT && rf12_canSend()) {
       Serial.println("RF12 sends Struct type 3");
       rf12_sendStart(0, &outData_3, sizeof outData_3); //0 is header. anders eens 2 proberen.
       // optional: rf12_sendWait(2); // wait for send to finish
       pendingOutput = 0;
    
    //just repeat else if statements above to add more structs (and add return type in getdatafromarray() function
}  
   }
  
  // ****** end RF12 transceiver code *****
  
 void procesInData(){
   
  Serial.print("RF12 data ontvangen ");
  
  //Identify type of struct:
  byte WhichStruct = rf12_data[0]; //first byte in rf12 data (which is part of struct) identifies struct type
  
  switch (WhichStruct){
   //add more cases when you want to process more incoming data types
   
    case SOLAR_STRUCT: //Struct of Solarmonitor
      Serial.println("Received StructType = 1 - Solar Monitor");
      memcpy(&inData_1, (byte*) rf12_data, sizeof inData_1);  
      ProcessReceivedDomo(inData_1.DomoStatus);
      Struct2ASCII();
      
        if(inData_1.Doorbell == 1) //when doorbell should ring, set screen to 6.
          screen = 6;
          
      NoDataReceived = millis(); //reset nodata received identifier with current millis.
      break;
      
    case TIME_STRUCT:
      Serial.println("Received StructType = 8 - Time sync");
      memcpy(&inData_8, (byte*) rf12_data, sizeof inData_8);
      RTC.set(inData_8.time);   // set the RTC and the system time to the received value
      setTime(inData_8.time); 
      break;
      
    case SUNTIMES_STRUCT: //Struct of Sun Moon Times
      Serial.println("Received StructType = 2 - Sun Moon Times");
      memcpy(&inData_2, (byte*) rf12_data, sizeof inData_2);
     // Struct2ASCII();
      break;
    
    
    case TEMP_STRUCT: //Struct of sensor
      Serial.println("Received StructType = 3 - Temp data");
      memcpy(&inData_3, (byte*) rf12_data, sizeof inData_3);
     
      if(nodeID == 2){ //nodeID2 is the outdoor temperature sensor
        outdoor_temp = float(inData_3.temp)/100;
        outdoor_humidity = float(inData_3.humidity)/100;
      }
      else if(nodeID == 4){ //nodeID 4 is for bedroom of kids
        kid_temp = float(inData_3.temp)/100;
     // kid_humidity = float(inData_3.humidity)/100;
      }
      //Implement something to determine which temp data you want to receive. i.e only outdoor temp from sensor Node ID xx
      break;
    
    default:
      break;
  } //end switch
  
  
 }
 
 
