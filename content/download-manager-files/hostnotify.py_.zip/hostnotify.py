#!/usr/bin/env python 

import urllib, urllib2
import time
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("URL", help="Checks connection to this URL. Write http://hostname:port")


args = parser.parse_args()


#version
VERSION = "HostOnline Checker v0.3"
print VERSION

key = "YOUR-SCENARIO-KEY-HERE"	#Pushingbox.com scenario Key


class pushingbox():
	url = ""
	def __init__(self, key):
		url = 'http://api.pushingbox.com/pushingbox'
		values = {'devid' : key}
		try:
			data = urllib.urlencode(values)
			req = urllib2.Request(url, data)
			sendrequest = urllib2.urlopen(req)
		except Exception, detail:
			print "Error ", detail



#Try to make the connection to the supplied URL. 
try:
  f = urllib2.urlopen(urllib2.Request(args.URL))
  deadLinkFound = False
except:
  deadLinkFound = True
  

if deadLinkFound == True:
	
	#send message via Pushingbox.com
	pushingbox(key)

	print "URL: ", args.URL, "is not reachable"
	#Add other code if you like for performing tasks when connection is lost
	#i.e. I had code here to remotely switch relays to shutdown power of IP Camera.
	
	
else:
		print "URL: ", args.URL, "is reachable"
		#add other code to perform when service is reachable.
