#!/bin/sh

## Lock mechanisme to prevent the script from running twice (in parallel)

set -e
 
scriptname=$(basename $0)
lock="/var/run/${scriptname}"
 
exec 200>$lock
flock -n 200 || exit 1
 
## The code:
pid=$$
echo $pid 1>&200

#Logfile - Modify the path to where you want to write the log file. It contains date/time stamp
LOGFILE=/volume1/Scripts/YourRsyncScriptLog`date +%Y%m%d%H%M%S`.log

# rsync options - change Ip to your RaspberryPi IP Address or DNS of remote location!
DEST=synology@192.168.1.200:/mnt/usbdrive/MyBackup/

#Set the source directory you want to backup.
SRC="/volume1 "

#Options: add 'z' for compression, add 'n' for dryrun (test) so -avRzn
OPTIONS="-avR "

#Write start time/date in logfile
echo "`date +%Y-%m-%d_%H:%M:%S` : Starting rsync" >> $LOGFILE
start=`date +%s` 


#perform rsync (modify path to your exclude file!)
rsync $OPTIONS --exclude-from=/volume1/Scripts/Exclude.txt $SRC $DEST >> $LOGFILE

#calculate total seconds between start and end.
end=`date +%s`
diff=`expr $end - $start`

#Write end time/date to logfile
echo "`date +%Y-%m-%d_%H:%M:%S` : Finished rsync" >> $LOGFILE
echo "Elapsed time = $diff seconds"
