/*  DATASTRUCTURE  --- Version 0.7  -- 20 march 2013  --- www.vdsar.net
This file contains the data structures used in "my" sensors and receivers. By using this file I'm sure I always use the same 
structures in every device. 
I believe there is no need to comment out any of those. The structs are initialized in the source code of the application.

v0.6 - changed NetToday from unsigned int to INT to fix - sign not being displayed (values became 65.xxx instead of -xxx
v0.7 - added StringStruct (used in the Arduino_RF12_Serial sketch to send commands from display arduino to domoticabox)
v0.8 - added TotalToday to payload1
*/
typedef struct { //currently 22 bytes of size
  	byte which_Struct;
  	byte NodeID;
  	unsigned int actual;  
  	unsigned int today; 
  	unsigned int peak; 
  	unsigned long total; 
  	unsigned int TotalActual;
  	unsigned int Nactual;  
  	unsigned int NactualReturn; 
  	unsigned int GasUsage; 
    int NetToday;
    int TotalToday;
  	long DomoStatus;
  	byte Doorbell;
  } Payload_1; //struct for solarmonitor & domoticaSwitches


typedef struct { 
 	byte which_Struct;
  	byte NodeID;
  	char sunrise[6];
  	char sunset[6];
  	char moonrise[6];
  	char moonset[6];
  } Payload_2; // struct for Sunrise/set and Moonrise/set times
  
/*  
typedef struct { //bytes: 14
  byte which_Struct;
  byte NodeID;
  int humidity; //was humidity before
  int temp; //was temp before
  int light; //was light before
  int supplyV; //
  unsigned long sendcounter;
  } Payload_3; //struct for sensor 
*/
 
 typedef struct { //bytes: 20
  byte which_Struct;
  byte NodeID;
  int var_1; 
  int var_2; 
  int var_3; 
  int var_4; 
  int var_5; 
  int supplyV; 
  unsigned long sendcounter;
  } Payload_3; //struct for sensor 
  
typedef struct {
  	byte which_Struct;
  	byte NodeID;
  	int SensorType;
  	float Value1;
  	float Value2;
  	float Value3;
  	int Voltage;
  } Payload_4; //struct for sensor 
 
 
 typedef struct { //RGB led
    byte which_Struct;
    int red;              // sensor value
    int green;
    int blue;
    int supplyV;          // tx voltage
 } Payload_5;


typedef struct { //doorbell and domostatus NOT IN USE. Still using Domo & doorbell in Struct 1.
  	byte which_Struct;
 	byte NodeID;	
  	long DomoStatus;
  	byte Doorbell;
 } Payload_6;
 
 
 typedef struct {
      byte which_Struct;
      byte NodeID;	  
      int alarm;	// alarm status
     int supplyV;	// Supply voltage
 } Payload_7;
 
 
 typedef struct { //time sync
   byte which_Struct;
   unsigned long time;
 } Payload_8;
 
 typedef struct { //string (char) struct
 	byte which_Struct;
 	char Command_1[25];
 	} Payload_9;
 	
  
 #define SOLAR_STRUCT 1  //this defines the struct. Used in RF12, Getdatafromarray() to identify pendingoutput en ID the structure to be send
 #define SUNTIMES_STRUCT 2
 #define TEMP_STRUCT 3
 #define SENSOR_STRUCT 4
 #define RGB_STRUCT 5
 #define DOMO_STRUCT 6
 #define ALARM_STRUCT 7
 #define TIME_STRUCT 8
 #define STRING_STRUCT 9
 
