#/bin/sh



## Lock mechanisme om dubbel starten te voorkomen

set -e
 
scriptname=$(basename $0)
lock="/var/run/${scriptname}"
 
exec 200>$lock
flock -n 200 || exit 1
 
## The code:
pid=$$
echo $pid 1>&200

#wake up the source computer
wget http://192.168.x.xxx:5000/webman/3rdparty/wol/index.cgi?wol_mac=aa:bb:cc:dd:ee:ff
#wait 20 seconds to get awake
sleep 20

LOGFILE=/volume1/Scripts/RsyncLog/Mac2Synology`date +%Y%m%d%H%M%S`.log

# rsync options
DEST=/volume1/homes/USERNAME/MAC_Backup
SRC="MACUSERNAME@IP_OF_MAC:/Users/MACUSERNAME/Pictures/iPhoto-bibliotheek.photolibrary "
DEST2=/volume1/homes/USERNAME/MAC_Backup
SRC2="MACUSERNAME@IP_OF_MAC:/Users/MACUSERNAME/Movies/iMovie* "

#options contains the --delete parameter because I think it's best to keep the 
#iphoto and iMovie packages exactly the same and get rid of all stuff that should
#not be in there anymore.

#remome n from the options once the dryrun has proven you script is okay.
#first test the script and check the logfile what has happened. 

OPTIONS="-avRn --delete "

 
echo "`date +%Y-%m-%d_%H:%M:%S` : Starting rsync" >> $LOGFILE
start=`date +%s` 


echo "BACKUP PHOTO" >> $LOGFILE

rsync $OPTIONS $SRC $DEST >> $LOGFILE
echo "BACKUP MOVIE" >> $LOGFILE

rsync $OPTIONS $SRC2 $DEST >> $LOGFILE

#the WOL entry downloads the index.cgi file and saves it in the directory where the 
#script is started. Next command removes the unnecessary index.cgi? files

rm /volume1/Scripts/Rsync/index.cgi?wol_mac*

end=`date +%s`
diff=`expr $end - $start`

echo "`date +%Y-%m-%d_%H:%M:%S` : Finished rsync" >> $LOGFILE
echo "Elapsed time = $diff seconds" >> $LOGFILE
