/*
433 Mhz to MQTT Gateway by Alexander van der Sar - www.vdsar.net
Receive commands using 433 Mhz kits like Action, Klik Aan/uit, Elro and send the code to 
a MQTT Topic on the MQTT broker. Next with Node-Red you can control things based on the received codes

*/
#define VERSION "V0.1 - 433Mhz to MQTT Gateway - www.vdsar.net"
#include <SPI.h>
#include <Ethernet.h>
#include <PubSubClient.h>
#include <RemoteReceiver.h>

// Update these with values suitable for your network.
byte mac[]    = {  0xAE, 0xED, 0xBC, 0xFE, 0xFE, 0xDC };
IPAddress ip(192, 168, 9, 171); //YOUR IP HERE
IPAddress server(192, 168, 9, 152); //IP OF YOUR MQTT Broker (Mosquitto or alike)
long code=0, prev_code=0;

unsigned long timestamp;
void callback(char* topic, byte* payload, unsigned int length) {
  // handle MQTT message arrived. 
}

EthernetClient ethClient;
PubSubClient client(server, 1883, callback, ethClient);

void setup()
{
  Serial.begin(115200);
  RemoteReceiver::init(1, 3, showCode);  // IRQ 1 (Pin3) or IRQ 0 (Pin2), wait for 3 x the code, Start ShowCode
  Serial.println(VERSION);
  Serial.println("Publishing codes to home/remotecontrol and arduino/version");
  
  Ethernet.begin(mac, ip);
  // Note - the default maximum packet size is 128 bytes. If the
  // combined length of clientId, username and password exceed this,
  // you will need to increase the value of MQTT_MAX_PACKET_SIZE in
  // PubSubClient.h
  
  if (client.connect("arduinoClient", "YOUR-MQ-USER", "YOUR-MQ-PASSWORD")) {
    client.publish("arduino/version",VERSION);
    //client.subscribe("inTopic");
  }
}
  
void loop()
{
  client.loop();
  char buf[12];

  if(code != prev_code){ //prevent the same code to be send repeatedly
    timestamp = millis();
    prev_code = code;
    client.publish("home/remotecontrol",ltoa(code, buf,10));
    }

  if(millis() > timestamp + 2000){ //prevent the same code to be send within 2 seconds.
    prev_code = 0;
    code = 0;
  }
  
}

void showCode(unsigned long receivedCode, unsigned int period) {
  // Note: interrupts are disabled. You can re-enable them if needed.

  code = receivedCode; //Calling the MQ publish statement is not working, therefore use a variable and call MQTT publish in loop()
  // Print the received code.
  /*
  Serial.print("Code: ");
  Serial.print(receivedCode);
  Serial.print(", period duration: ");
  Serial.print(period);
  Serial.println("us.");
  */
}
